using UnityEngine;

public class Tower : MonoBehaviour
{
    [Header("Base Stats")]
    public float baseRange = 3f;
    public float baseDamage = 10f;
    public float baseAttackSpeed = 1f;
    public int baseCost = 100;

    [Header("Upgrade Info")]
    public int rangeLevel = 1;
    public int damageLevel = 1;
    public int attackSpeedLevel = 1;
    public float upgradeMultiplier = 1.2f;
    
    protected float currentRange;
    protected float currentDamage;
    protected float currentAttackSpeed;
    protected float totalSpent;

    protected virtual void Start()
    {
        currentRange = baseRange;
        currentDamage = baseDamage;
        currentAttackSpeed = baseAttackSpeed;
        totalSpent = baseCost;
    }

    public void UpgradeRange()
    {
        int cost = (int)(baseCost * 0.5f * rangeLevel);
        if (GameManager.Instance.CanPlaceTower(cost))
        {
            GameManager.Instance.SpendGold(cost);
            rangeLevel++;
            currentRange *= upgradeMultiplier;
            totalSpent += cost;
        }
    }

    public void UpgradeDamage()
    {
        int cost = (int)(baseCost * 0.6f * damageLevel);
        if (GameManager.Instance.CanPlaceTower(cost))
        {
            GameManager.Instance.SpendGold(cost);
            damageLevel++;
            currentDamage *= upgradeMultiplier;
            totalSpent += cost;
        }
    }

    public void UpgradeAttackSpeed()
    {
        int cost = (int)(baseCost * 0.7f * attackSpeedLevel);
        if (GameManager.Instance.CanPlaceTower(cost))
        {
            GameManager.Instance.SpendGold(cost);
            attackSpeedLevel++;
            currentAttackSpeed /= upgradeMultiplier;
            totalSpent += cost;
        }
    }

    public void SellTower()
    {
        int refund = (int)(totalSpent * 0.35f);
        GameManager.Instance.AddGold(refund);
        Destroy(gameObject);
    }
}

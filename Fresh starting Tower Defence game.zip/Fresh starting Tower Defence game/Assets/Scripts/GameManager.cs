using UnityEngine;
using System.Collections;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }
    
    [Header("Game Settings")]
    public int maxTowers = 10;
    public int currentWave = 0;
    public bool isGameStarted = false;
    public float timeBetweenWaves = 3f;
    public float nextWaveCountdown = 10f;

    [Header("Currency")]
    public int gold = 100;
    public int gems = 0;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void StartGame()
    {
        if (!isGameStarted)
        {
            isGameStarted = true;
            currentWave = 1;
            StartCoroutine(WaveCountdownRoutine());
        }
    }

    private IEnumerator WaveCountdownRoutine()
    {
        while (isGameStarted)
        {
            yield return new WaitForSeconds(1f);
            if (nextWaveCountdown > 0)
            {
                nextWaveCountdown--;
            }
            else
            {
                StartNextWave();
            }
        }
    }

    private void StartNextWave()
    {
        currentWave++;
        // Reset countdown for next wave
        nextWaveCountdown = 10f;
        
        // Add gem rewards for wave milestones
        if (currentWave == 100)
        {
            gems += 25;
        }
        else if (currentWave % 10 == 0)
        {
            gems += Mathf.Max(1, 25 * currentWave / 100);
        }
    }

    public bool CanPlaceTower(int cost)
    {
        return gold >= cost;
    }

    public void SpendGold(int amount)
    {
        gold -= amount;
    }

    public void AddGold(int amount)
    {
        gold += amount;
    }
}

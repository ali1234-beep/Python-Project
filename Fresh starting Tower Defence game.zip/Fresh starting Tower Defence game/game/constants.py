import pygame

# Screen settings
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720
FPS = 60
MARGIN = 60  # Margin from screen edges

# Base settings
BASE_MAX_HEALTH = 25
BASE_SIZE = 80  # Castle width
PATH_COLLISION_MARGIN = 50  # Minimum distance from path to place towers

# Path points for winding path
PATH_POINTS = [
    (0, SCREEN_HEIGHT // 3),  # Start from left side
    (SCREEN_WIDTH // 4, SCREEN_HEIGHT // 3),  # First horizontal
    (SCREEN_WIDTH // 4, SCREEN_HEIGHT // 4),  # Up
    (3 * SCREEN_WIDTH // 4, SCREEN_HEIGHT // 4),  # Second horizontal
    (3 * SCREEN_WIDTH // 4, 3 * SCREEN_HEIGHT // 4),  # Down
    (SCREEN_WIDTH // 2, 3 * SCREEN_HEIGHT // 4),  # Third horizontal
    (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2),  # Up slightly
    (SCREEN_WIDTH - BASE_SIZE, SCREEN_HEIGHT // 2)  # End at right side
]
PATH_START = PATH_POINTS[0]  # First point
PATH_END = PATH_POINTS[-1]  # Last point

# Colors
BACKGROUND_COLOR = (34, 139, 34)  # Dark green grass color
UI_BACKGROUND = (41, 41, 41)
UI_TEXT = (255, 255, 255)
WAVE_TEXT_COLOR = (255, 255, 255)  # White text for wave counter
GOLD_COLOR = (255, 215, 0)
GEM_COLOR = (0, 191, 255)
PATH_COLOR = (139, 69, 19)  # Brown dirt path
DECORATION_COLORS = {
    'tree': (0, 100, 0),  # Dark green
    'rock': (128, 128, 128)  # Gray
}

# Game settings
MAX_TOWERS = 10
TOWER_SELL_RATIO = 0.35
WAVE_INTERVAL = 3  # seconds

# Path settings
PATH_COLOR = (139, 69, 19)  # Brown dirt path
PATH_WIDTH = 40

# Tower types
TOWER_TYPES = {
    'archer': {
        'cost': 100,
        'range': 150,
        'damage': 20,
        'attack_speed': 1.0,
        'projectile_speed': 300,
        'damage_type': 'ranged'
    },
    'warrior': {
        'cost': 150,
        'range': 60,
        'damage': 40,
        'attack_speed': 0.8,
        'damage_type': 'melee'
    },
    'mage': {
        'cost': 200,
        'range': 120,
        'damage': 30,
        'attack_speed': 1.2,
        'projectile_speed': 250,
        'damage_type': 'magic'
    }
}

# Enemy types
ENEMY_TYPES = {    'normal': {
        'health': 40,
        'speed': 100,  # Moderate speed
        'gold_value': 10,
        'color': (200, 50, 50),  # Deep red
        'size': 12,  # Smaller size
        'resistances': {'melee': 1.0, 'ranged': 1.0, 'magic': 1.0}
    },
    'armored': {
        'health': 80,
        'speed': 80,  # Slower speed
        'gold_value': 20,
        'color': (70, 70, 80),  # Steel gray
        'size': 14,  # Slightly larger
        'resistances': {'melee': 0.5, 'ranged': 0.8, 'magic': 1.2}
    },
    'fast': {
        'health': 25,
        'speed': 200,  # Fast speed
        'gold_value': 15,
        'color': (255, 165, 0),  # Orange
        'size': 10,  # Smallest size
        'resistances': {'melee': 1.2, 'ranged': 0.8, 'magic': 1.0}
    }
}

# Boss settings
BOSS_STATS_MULTIPLIER = 5  # Base multiplier for boss stats
MEGA_BOSS_MULTIPLIER = 10  # Multiplier for wave 100 boss

# Settings defaults
DEFAULT_SETTINGS = {
    'volume': 0.5,  # 0.0 to 1.0
    'show_health_bars': True,
    'show_damage_numbers': True,
    'show_tower_ranges': False,
    'background_animations': True
}

# UI Colors for menus
MENU_COLORS = {
    'background': (0, 0, 0, 180),  # Semi-transparent black
    'button': (70, 70, 70),
    'button_hover': (90, 90, 90),
    'button_text': (255, 255, 255),
    'slider_bar': (100, 100, 100),
    'slider_handle': (200, 200, 200),
    'checkbox': (100, 100, 100),
    'checkbox_checked': (0, 255, 0)
}

# UI Settings
BOTTOM_BAR_HEIGHT = 100
UI_ICON_SIZE = 28

# Resource panel settings
RESOURCE_PANEL_WIDTH = 180  # Wider panels for better spacing
RESOURCE_PANEL_HEIGHT = 70  # Taller panels for better visibility
BOTTOM_BAR_HEIGHT = 100  # Slightly taller bottom bar

# UI icon configurations
UI_ICONS = {
    'gold': {
        'size': UI_ICON_SIZE,
        'color': GOLD_COLOR,
        'points': [  # Medieval coin with crown design
            (0, -12), (8, -10), (12, -4), 
            (12, 0), (12, 4), (8, 10),
            (0, 12), (-8, 10), (-12, 4),
            (-12, 0), (-12, -4), (-8, -10)
        ],
        'crown_points': [  # Crown detail on coin
            (-6, -6), (-4, -8), (-2, -6),
            (0, -8), (2, -6), (4, -8),
            (6, -6)
        ]
    },
    'gems': {
        'size': UI_ICON_SIZE,
        'color': GEM_COLOR,
        'points': [  # Faceted gem shape
            (0, -15), (8, -8), (12, 0),
            (8, 8), (0, 15), (-8, 8),
            (-12, 0), (-8, -8)
        ],
        'facet_lines': [  # Internal facet details
            [(-8, -8), (8, 8)],
            [(8, -8), (-8, 8)],
            [(0, -15), (0, 15)]
        ]
    },
    'towers': {
        'size': UI_ICON_SIZE,
        'color': UI_TEXT,
        'points': [  # Medieval tower with crenellations
            (-12, 15),  # Base
            (-12, -6),  # Main tower walls
            (-14, -6),  # Left merlon
            (-14, -9),
            (-10, -9),  # Left crenel
            (-10, -6),
            (-2, -6),
            (-2, -12),  # Center turret
            (2, -12),
            (2, -6),
            (10, -6),
            (10, -9),   # Right crenel
            (14, -9),
            (14, -6),   # Right merlon
            (12, -6),
            (12, 15)    # Base
        ]
    },
    'base_health': {
        'size': UI_ICON_SIZE,
        'color': (220, 50, 50),  # Red
        'points': [  # Fortified castle shape
            (-15, 15),  # Base left
            (-15, -3),  # Wall left
            (-13, -3),  # Left tower
            (-13, -9),  # Left battlements
            (-15, -9),
            (-15, -12),
            (-11, -12),
            (-11, -9),
            (-7, -9),   # Center-left tower
            (-7, -3),
            (7, -3),    # Center-right tower
            (7, -9),
            (11, -9),   # Right battlements
            (11, -12),
            (15, -12),
            (15, -9),
            (13, -9),
            (13, -3),   # Right tower
            (15, -3),   # Wall right
            (15, 15)    # Base right
        ],
        'detail_points': [  # Additional architectural details
            [(-9, 0), (-9, -3)],  # Arrow slits
            [(0, 0), (0, -3)],
            [(9, 0), (9, -3)]
        ]
    }
}

# Decoration settings
DECORATIONS = [
    {
        'type': 'house1',
        'positions': [
            (120, 80),  # Top left
            (SCREEN_WIDTH - 180, 80),  # Top right
            (120, SCREEN_HEIGHT - 180),  # Bottom left
            (SCREEN_WIDTH - 180, SCREEN_HEIGHT - 180),  # Bottom right
        ],
        'image_path': './Assets/The Fan-tasy Tileset (Free) 1.5.1/Art/Buildings/House_Hay_1.png'
    },
    {
        'type': 'tree1',
        'positions': [
            # Top section trees
            (50, 50), (200, 50), (400, 50), (600, 50), (800, 50), (1000, 50),
            # Bottom section trees
            (50, SCREEN_HEIGHT - 100), (200, SCREEN_HEIGHT - 100),
            (400, SCREEN_HEIGHT - 100), (600, SCREEN_HEIGHT - 100),
            (800, SCREEN_HEIGHT - 100), (1000, SCREEN_HEIGHT - 100),
            # Middle safe spots (away from path)
            (150, 300), (900, 300), (150, 500), (900, 500),
        ],
        'image_path': './Assets/The Fan-tasy Tileset (Free) 1.5.1/Art/Trees and Bushes/Tree_Emerald_1.png'
    },    {
        'type': 'tree2',
        'positions': [
            # Trees in safe corners
            (250, 120), (SCREEN_WIDTH - 250, 120),
            (250, SCREEN_HEIGHT - 120), (SCREEN_WIDTH - 250, SCREEN_HEIGHT - 120),
            # Additional safe spots
            (500, 150), (700, 150),
            (500, SCREEN_HEIGHT - 150), (700, SCREEN_HEIGHT - 150)
        ],
        'image_path': './Assets/The Fan-tasy Tileset (Free) 1.5.1/Art/Trees and Bushes/Tree_Emerald_2.png'
    },
    {
        'type': 'rock1',
        'positions': [
            # Rocks near trees for natural grouping
            (80, 80), (180, 80), (SCREEN_WIDTH - 80, 80), (SCREEN_WIDTH - 180, 80),
            (80, SCREEN_HEIGHT - 80), (180, SCREEN_HEIGHT - 80),
            (SCREEN_WIDTH - 80, SCREEN_HEIGHT - 80), (SCREEN_WIDTH - 180, SCREEN_HEIGHT - 80),
            # Additional rocks in safe spots
            (300, 100), (900, 100),
            (300, SCREEN_HEIGHT - 100), (900, SCREEN_HEIGHT - 100)
        ],
        'image_path': './Assets/The Fan-tasy Tileset (Free) 1.5.1/Art/Rocks/Rock_Brown_1.png'
    }
]

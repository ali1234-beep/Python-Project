class CurrencyManager:    
    def __init__(self):
        self.gold = 150  # Starting gold
        self.gems = 0
        
    def add_gold(self, amount):
        self.gold += amount
        
    def add_gems(self, amount):
        self.gems += amount
        
    def spend(self, amount):
        if self.can_spend(amount):
            self.gold -= amount
            return True
        return False
        
    def spend_gems(self, amount):
        if self.can_spend_gems(amount):
            self.gems -= amount
            return True
        return False
        
    def can_spend(self, amount):
        return self.gold >= amount
        
    def can_spend_gems(self, amount):
        return self.gems >= amount

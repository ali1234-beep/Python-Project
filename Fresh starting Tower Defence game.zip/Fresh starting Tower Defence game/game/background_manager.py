"""Simple background manager test"""

__all__ = ['BackgroundManager']

import pygame
import os
import random

class Decoration:
    def __init__(self, image, x, y):
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

class BackgroundManager:
    def __init__(self):
        self.decorations = []
        self.load_assets()

    def load_assets(self):
        base_path = os.path.join("Assets", "The Fan-tasy Tileset (Free) 1.5.1", "Art")
        
        # Load trees and bushes
        self.tree_images = []
        self.bush_images = []
        trees_path = os.path.join(base_path, "Trees and Bushes")
        for file in os.listdir(trees_path):
            if file.startswith("Tree_Emerald_"):
                img = pygame.image.load(os.path.join(trees_path, file)).convert_alpha()
                self.tree_images.append(img)
            elif file.startswith("Bush_Emerald_"):
                img = pygame.image.load(os.path.join(trees_path, file)).convert_alpha()
                self.bush_images.append(img)

        # Load houses
        self.house_images = []
        buildings_path = os.path.join(base_path, "Buildings")
        for file in os.listdir(buildings_path):
            if file.startswith("House_Hay_"):
                img = pygame.image.load(os.path.join(buildings_path, file)).convert_alpha()
                self.house_images.append(img)

        # Load rocks
        self.rock_images = []
        rocks_path = os.path.join(base_path, "Rocks")
        for file in os.listdir(rocks_path):
            if file.startswith("Rock_Brown_"):
                img = pygame.image.load(os.path.join(rocks_path, file)).convert_alpha()
                self.rock_images.append(img)

    def is_position_valid(self, rect, path_rects):
        # Check if decoration overlaps with path or other decorations
        for path_rect in path_rects:
            if rect.colliderect(path_rect):
                return False
        
        for decoration in self.decorations:
            if rect.colliderect(decoration.rect):
                return False
        
        return True

    def add_random_decorations(self, screen_size, path_rects, num_trees=10, num_bushes=8, num_houses=3, num_rocks=5):
        width, height = screen_size
        margin = 50  # Keep decorations away from screen edges

        for _ in range(num_trees):
            for attempt in range(20):  # Try 20 times to place each decoration
                x = random.randint(margin, width - margin)
                y = random.randint(margin, height - margin)
                img = random.choice(self.tree_images)
                rect = img.get_rect(topleft=(x, y))
                if self.is_position_valid(rect, path_rects):
                    self.decorations.append(Decoration(img, x, y))
                    break

        for _ in range(num_bushes):
            for attempt in range(20):
                x = random.randint(margin, width - margin)
                y = random.randint(margin, height - margin)
                img = random.choice(self.bush_images)
                rect = img.get_rect(topleft=(x, y))
                if self.is_position_valid(rect, path_rects):
                    self.decorations.append(Decoration(img, x, y))
                    break

        for _ in range(num_houses):
            for attempt in range(20):
                x = random.randint(margin, width - margin)
                y = random.randint(margin, height - margin)
                img = random.choice(self.house_images)
                rect = img.get_rect(topleft=(x, y))
                if self.is_position_valid(rect, path_rects):
                    self.decorations.append(Decoration(img, x, y))
                    break

        for _ in range(num_rocks):
            for attempt in range(20):
                x = random.randint(margin, width - margin)
                y = random.randint(margin, height - margin)
                img = random.choice(self.rock_images)
                rect = img.get_rect(topleft=(x, y))
                if self.is_position_valid(rect, path_rects):
                    self.decorations.append(Decoration(img, x, y))
                    break

    def draw(self, screen):
        for decoration in self.decorations:
            screen.blit(decoration.image, decoration.rect)

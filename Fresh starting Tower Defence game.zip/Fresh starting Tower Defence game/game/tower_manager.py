import pygame
from .constants import *
from .tower import Tower

class TowerManager:
    def __init__(self, currency_manager):
        self.towers = []
        self.currency_manager = currency_manager
        self.selected_tower = None
        self.enemy_manager = None  # Will be set by game state

    def is_near_path(self, position, game_state):
        """Check if a position is too close to the path"""
        path = game_state.wave_manager.path
        mouse_pos = pygame.math.Vector2(position)

        for i in range(len(path) - 1):
            start = pygame.math.Vector2(path[i])
            end = pygame.math.Vector2(path[i + 1])
            
            # Vector from start to end of path segment
            segment = end - start
            # Vector from start to mouse position
            to_mouse = mouse_pos - start
            
            # Length of the path segment
            segment_length = segment.length()
            # Calculate how far along the path segment the closest point is
            if segment_length == 0:
                # Handle case where path points are the same
                t = 0
            else:
                t = max(0, min(1, to_mouse.dot(segment) / (segment_length * segment_length)))
            
            # Find the closest point on the path segment
            closest = start + segment * t
            
            # Check distance to closest point
            distance = (mouse_pos - closest).length()
            
            # PATH_WIDTH/2 + extra margin for tower radius
            if distance < (PATH_WIDTH/2 + 30):
                return True
                
        return False

    def try_place_tower(self, position, tower_type):
        """Try to place a tower at the given position"""
        # Convert position to tuple for consistency
        position = (int(position[0]), int(position[1]))
        
        # Check if we've reached the tower limit
        if len(self.towers) >= MAX_TOWERS:
            return False
            
        # Check if we can afford the tower
        cost = TOWER_TYPES[tower_type]['cost']
        if not self.currency_manager.can_spend(cost):
            return False
            
        # Check if position is valid (not overlapping other towers)
        for tower in self.towers:
            if pygame.math.Vector2(position).distance_to(tower.position) < 40:
                return False
                
        # Check if tower is too close to path - do this check last
        if self.is_near_path(position, self.enemy_manager.game_state):
            return False
                
        # All checks passed, place the tower
        self.currency_manager.spend(cost)
        new_tower = Tower(position, tower_type)
        self.towers.append(new_tower)
        return True

    def select_tower(self, position):
        """Select a tower at the given position"""
        # Convert position to Vector2 for easier distance calculation
        pos_vec = pygame.math.Vector2(position)
        
        # Check towers in reverse order (top-most first)
        for tower in reversed(self.towers):
            if pos_vec.distance_to(tower.position) < 20:  # Fixed selection radius
                self.selected_tower = tower
                return tower
                
        self.selected_tower = None
        return None

    def sell_tower(self, tower):
        """Sell the given tower"""
        if tower in self.towers:
            self.currency_manager.add_gold(tower.get_sell_value())
            self.towers.remove(tower)
            if tower == self.selected_tower:                self.selected_tower = None

    def upgrade_tower(self, tower, attribute):
        """Upgrade a specific attribute of the given tower"""
        if tower in self.towers:
            cost = tower.get_upgrade_cost(attribute)
            if self.currency_manager.can_spend(cost):
                self.currency_manager.spend(cost)
                tower.upgrade(attribute)
                return True
            return False
        return False

    def update(self, dt=None):
        """Update all towers"""
        # Use fixed timestep for consistent updates, ignoring passed dt
        fixed_dt = 1.0 / FPS
        enemies = self.enemy_manager.enemies if self.enemy_manager else []
        for tower in self.towers:
            tower.update(fixed_dt, enemies)  # Pass actual enemies list
            
    def draw(self, screen):
        """Draw all towers and selection indicators"""
        for tower in self.towers:
            # Draw tower with selection state
            tower.draw(screen, tower == self.selected_tower)
            # Draw selection ring if tower is selected
            if tower == self.selected_tower:
                pygame.draw.circle(screen, (255, 255, 0), tower.position, tower.radius + 3, 2)

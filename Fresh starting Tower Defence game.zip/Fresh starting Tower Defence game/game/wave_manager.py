import pygame
import random
import math
from .constants import *
from .enemy import Enemy

class WaveManager:
    def __init__(self, enemy_manager):
        """Initialize wave manager"""
        self.enemy_manager = enemy_manager
        self.current_wave = 0
        self.wave_in_progress = False
        self.next_wave_ready = True
        self.enemies_to_spawn = 0
        self.spawn_delay = 1.0
        self.enemy_spawn_timer = 0
        self.wave_timer = 0
        self.wave_interval = 10.0  # Time in seconds between waves
        
        # Wave timer display attributes
        self.countdown_active = False
        self.countdown_timer = 0
        self.countdown_duration = 3.0  # 3-second countdown
        self.wave_halfway = False
        self.font = pygame.font.Font(None, 36)  # Default font for timer display

        # Load building images from tileset
        self.building_images = {
            'house1': pygame.image.load('Assets/The Fan-tasy Tileset (Free) 1.5.1/Art/Buildings/House_Hay_1.png'),
            'house2': pygame.image.load('Assets/The Fan-tasy Tileset (Free) 1.5.1/Art/Buildings/House_Hay_2.png'),
            'house3': pygame.image.load('Assets/The Fan-tasy Tileset (Free) 1.5.1/Art/Buildings/House_Hay_3.png'),
            'house4': pygame.image.load('Assets/The Fan-tasy Tileset (Free) 1.5.1/Art/Buildings/House_Hay_4_Purple.png'),
            'well': pygame.image.load('Assets/The Fan-tasy Tileset (Free) 1.5.1/Art/Buildings/Well_Hay_1.png')
        }
        
        # Load tree images from tileset
        self.tree_images = {
            'tree1': pygame.image.load('Assets/The Fan-tasy Tileset (Free) 1.5.1/Art/Trees and Bushes/Tree_Emerald_1.png'),
            'tree2': pygame.image.load('Assets/The Fan-tasy Tileset (Free) 1.5.1/Art/Trees and Bushes/Tree_Emerald_2.png'),
            'tree3': pygame.image.load('Assets/The Fan-tasy Tileset (Free) 1.5.1/Art/Trees and Bushes/Tree_Emerald_3.png')
        }
        
        # Scale the images with different scales for buildings and trees
        building_scale = 0.9  # Reduced from 1.3
        tree_scale = 1.4     # Reduced from 2.0
        
        # Scale buildings
        for key in self.building_images:
            img = self.building_images[key]
            new_size = (int(img.get_width() * building_scale), int(img.get_height() * building_scale))
            self.building_images[key] = pygame.transform.scale(img, new_size)
            
        # Scale trees
        for key in self.tree_images:
            img = self.tree_images[key]
            new_size = (int(img.get_width() * tree_scale), int(img.get_height() * tree_scale))
            self.tree_images[key] = pygame.transform.scale(img, new_size)

        self.path = self.generate_path()
        self.enemy_types = ['normal']
        self.decorations = self.generate_decorations()
        
        # Load dirt path texture
        try:
            self.dirt_path = pygame.image.load('Assets/SeamlessGroundTextures09012024/SeamlessGroundTextures/Dirt Path.png').convert_alpha()            # Scale the dirt texture to be much smaller
            path_scale_x = 0.04  # Much smaller width
            path_scale_y = 0.06  # Much smaller length
            original_size = self.dirt_path.get_size()
            new_size = (int(original_size[0] * path_scale_x), 
                       int(original_size[1] * path_scale_y))
            self.dirt_path = pygame.transform.scale(self.dirt_path, new_size)
            # Pre-rotate the texture 90 degrees
            self.dirt_path = pygame.transform.rotate(self.dirt_path, 90)
        except pygame.error as e:
            print(f"Error loading dirt path texture: {e}")
            self.dirt_path = None

    def generate_path(self):
        """Generate a path for enemies to follow"""
        # Use the predefined PATH_POINTS from constants
        return PATH_POINTS

    def generate_decorations(self):
        """Generate positions for background decorations"""
        decorations = {
            'trees': [],
            'rocks': [],
            'buildings': []
        }
        
        # Constants for decoration placement
        MARGIN = 80
        MIN_BUILDING_SPACING = 10
        MIN_TREE_SPACING = 50
        PATH_CLEARANCE = 55  # Increased from 120
        
        # Define specific areas for controlled decoration placement
        areas = {
            'top_left': {'x': (MARGIN, 300), 'y': (MARGIN, 250)},
            'top_left_corner': {'x': (50, 200), 'y': (50, 150)},
            'top_right': {'x': (SCREEN_WIDTH - 300, SCREEN_WIDTH - MARGIN), 'y': (50, 200)},
            'bottom_left': {'x': (100, 400), 'y': (SCREEN_HEIGHT - 300, SCREEN_HEIGHT - MARGIN)},
            'bottom_right': {'x': (SCREEN_WIDTH - 300, SCREEN_WIDTH - MARGIN), 
                           'y': (SCREEN_HEIGHT - 300, SCREEN_HEIGHT - MARGIN)}
        }
        
        def is_valid_position(x, y, decoration_type, min_distance):
            # Check screen bounds with margin
            if x < MARGIN or x > SCREEN_WIDTH - MARGIN or y < MARGIN or y > SCREEN_HEIGHT - MARGIN:
                return False
                
            # Much stricter path clearance
            if decoration_type == 'trees':
                path_clear = PATH_CLEARANCE  # Same clearance for both now
            else:
                path_clear = PATH_CLEARANCE * 1.2  # Even more clearance for buildings
                
            # Double check path proximity with strict clearance
            if self.is_near_path((x, y), path_clear):
                return False
                
            # Extra validation for areas near path intersections
            for i in range(len(self.path) - 2):
                point = pygame.math.Vector2(self.path[i + 1])
                if abs(x - point.x) < path_clear * 1.3 and abs(y - point.y) < path_clear * 1.3:
                    return False
            
            # Check spacing from other decorations
            return not any(
                abs(x - pos[0]) < min_distance and abs(y - pos[1]) < min_distance 
                for pos in (
                    coord if isinstance(coord, tuple) and len(coord) == 2 
                    else (coord[0], coord[1]) 
                    for coord in decorations[decoration_type]
                )
            )
        
        def try_add_decoration(count, decoration_type, min_distance, area=None):
            added = 0
            attempts = 0
            while added < count and attempts < count * 12:  # Even more attempts to find valid positions
                attempts += 1
                
                if area:
                    x = random.randint(area['x'][0], area['x'][1])
                    y = random.randint(area['y'][0], area['y'][1])
                else:
                    x = random.randint(MARGIN, SCREEN_WIDTH - MARGIN)
                    y = random.randint(MARGIN, SCREEN_HEIGHT - MARGIN)
                
                if is_valid_position(x, y, decoration_type, min_distance):
                    if decoration_type == 'buildings':
                        building_type = random.choice(['house1', 'house2', 'house3', 'house4'])
                        decorations[decoration_type].append((x, y, building_type))
                        
                        # Even more selective well placement
                        if random.random() < 0.1 and not self.is_near_path((x, y), PATH_CLEARANCE * 2):
                            well_x = x + random.randint(-30, 30)
                            well_y = y + random.randint(-30, 30)
                            if is_valid_position(well_x, well_y, decoration_type, min_distance * 0.7):
                                decorations[decoration_type].append((well_x, well_y, 'well'))
                    
                    elif decoration_type == 'trees':
                        tree_type = random.choice(['tree1', 'tree2', 'tree3'])
                        decorations[decoration_type].append((x, y, tree_type))
                    added += 1

        # Fill areas in order of priority
        try_add_decoration(2, 'trees', MIN_TREE_SPACING * 0.8, areas['top_left_corner'])
        
        for area_name, area in areas.items():
            if area_name == 'top_left':
                try_add_decoration(2, 'buildings', MIN_BUILDING_SPACING, area)
                try_add_decoration(3, 'trees', MIN_TREE_SPACING, area)
            elif area_name == 'bottom_left':
                try_add_decoration(2, 'buildings', MIN_BUILDING_SPACING, area)
                try_add_decoration(3, 'trees', MIN_TREE_SPACING, area)
            elif area_name == 'top_right':
                try_add_decoration(1, 'buildings', MIN_BUILDING_SPACING, area)
                try_add_decoration(2, 'trees', MIN_TREE_SPACING, area)
            elif area_name == 'bottom_right':
                try_add_decoration(1, 'buildings', MIN_BUILDING_SPACING, area)
                try_add_decoration(2, 'trees', MIN_TREE_SPACING, area)
        
        # Add remaining decorations
        try_add_decoration(3, 'buildings', MIN_BUILDING_SPACING)
        try_add_decoration(10, 'trees', MIN_TREE_SPACING)  # Reduced from 12
        
        return decorations

    def is_near_path(self, pos, min_distance=80):
        """Check if a position is too close to the path with absolute prevention of path overlap"""
        x, y = pos
        
        # Extra clearance for horizontal paths
        horizontal_path_clearance = min_distance * 1.5  # 50% more clearance for horizontal paths
        
        for i in range(len(self.path) - 1):
            point1 = pygame.math.Vector2(self.path[i])
            point2 = pygame.math.Vector2(self.path[i + 1])
            path_vec = point2 - point1
            pos_vec = pygame.math.Vector2(pos) - point1
            
            # Check if this is a horizontal path segment
            is_horizontal = abs(point2.y - point1.y) < 10
            actual_clearance = horizontal_path_clearance if is_horizontal else min_distance
            
            # Calculate closest point on path segment
            t = max(0, min(1, pos_vec.dot(path_vec) / path_vec.dot(path_vec)))
            closest = point1 + t * path_vec
            
            # Get distance to path
            distance = pos_vec.distance_to(closest)
            
            # Extra strict check for points near the path
            if distance < actual_clearance:
                return True
            
            # Additional check for path endpoints
            if (pos_vec.distance_to(point1) < actual_clearance or 
                pos_vec.distance_to(point2) < actual_clearance):
                return True
                
            # Extra check for horizontal paths - check above and below the path
            if is_horizontal:
                if abs(y - point1.y) < actual_clearance:
                    if point1.x <= x <= point2.x or point2.x <= x <= point1.x:
                        return True
                    
        return False

    def draw_castle_base(self, screen, pos, angle):
        """Draw a detailed castle base with towers and walls"""
        x, y = pos
        
        # Draw main circular foundation
        radius = 45
        pygame.draw.circle(screen, (80, 80, 80), pos, radius)  # Dark gray base
        pygame.draw.circle(screen, (120, 120, 120), pos, radius - 4)  # Lighter inner circle
        
        # Draw castle walls (rectangle with battlements)
        wall_width = 70
        wall_height = 50
        
        # Create a surface for the castle that we can rotate
        castle_surface = pygame.Surface((wall_width + 20, wall_height + 20), pygame.SRCALPHA)
        
        # Draw main castle body
        pygame.draw.rect(castle_surface, (140, 140, 140), 
                        (10, 20, wall_width, wall_height))  # Main wall
        
        # Draw battlements
        battlement_width = 10
        battlement_height = 10
        for i in range(6):
            x_pos = 10 + i * (battlement_width + 2)
            pygame.draw.rect(castle_surface, (160, 160, 160),
                           (x_pos, 10, battlement_width, battlement_height))
        
        # Draw towers on sides
        tower_radius = 15
        pygame.draw.circle(castle_surface, (130, 130, 130), 
                         (10, wall_height//2 + 20), tower_radius)  # Left tower
        pygame.draw.circle(castle_surface, (130, 130, 130),
                         (wall_width + 10, wall_height//2 + 20), tower_radius)  # Right tower
        
        # Draw tower tops
        pygame.draw.rect(castle_surface, (150, 150, 150),
                        (5, wall_height//2 - 5 + 20, 10, 10))  # Left tower top
        pygame.draw.rect(castle_surface, (150, 150, 150),
                        (wall_width + 5, wall_height//2 - 5 + 20, 10, 10))  # Right tower top
        
        # Draw gate
        gate_width = 20
        gate_height = 30
        gate_x = (wall_width - gate_width) // 2 + 10
        pygame.draw.rect(castle_surface, (60, 40, 20),
                        (gate_x, wall_height - gate_height + 20, gate_width, gate_height))
        
        # Add arch to gate
        pygame.draw.arc(castle_surface, (80, 60, 40),
                       (gate_x, wall_height - gate_height + 10 + 20,
                        gate_width, 20), 0, math.pi, 3)
        
        # Rotate the castle to match path direction
        rotated_castle = pygame.transform.rotate(castle_surface, -angle - 90)
        castle_rect = rotated_castle.get_rect(center=pos)
        
        # Draw the rotated castle
        screen.blit(rotated_castle, castle_rect)

    def draw_path(self, screen):
        """Draw the dirt path with texture and castle bases"""
        if self.dirt_path:
            # Draw textured path segments
            for i in range(len(self.path) - 1):
                start = pygame.math.Vector2(self.path[i])
                end = pygame.math.Vector2(self.path[i + 1])
                segment_vec = end - start
                segment_length = segment_vec.length()
                angle = math.degrees(math.atan2(segment_vec.y, segment_vec.x))
                
                # Calculate number of tiles needed
                tile_width = self.dirt_path.get_width()
                num_tiles = int(segment_length / (tile_width * 0.6)) + 2
                
                for j in range(num_tiles):
                    t = j / (num_tiles - 1)
                    pos_x = start.x + (segment_vec.x * t)
                    pos_y = start.y + (segment_vec.y * t)
                    
                    # Rotate and position the tile
                    rotated_tile = pygame.transform.rotate(self.dirt_path, -angle)
                    tile_rect = rotated_tile.get_rect(center=(pos_x, pos_y))
                    screen.blit(rotated_tile, tile_rect)

        # Draw castle bases at path ends
        for i in range(len(self.path) - 1):
            if i == len(self.path) - 2:  # Last segment
                end_point = self.path[-1]
                second_last_point = self.path[-2]
                direction = pygame.math.Vector2(end_point[0] - second_last_point[0],
                                             end_point[1] - second_last_point[1])
                if direction.length() > 0:
                    direction = direction.normalize()
                    # Calculate rotation angle for the castle
                    angle = math.degrees(math.atan2(direction.y, direction.x))
                    
                    # Position castle slightly beyond path end
                    castle_pos = (end_point[0] + direction.x * 20,
                                end_point[1] + direction.y * 20)
                    
                    # Draw the castle base
                    self.draw_castle_base(screen, castle_pos, angle)

    def draw_decorations(self, screen):
        """Draw all background decorations with y-axis depth sorting"""
        # Combine all decorations into a single list with their types
        all_decorations = []
        
        # Add buildings
        for x, y, building_type in self.decorations['buildings']:
            all_decorations.append(('building', (x, y, building_type), y))
            
        # Add trees
        for pos in self.decorations['trees']:
            if isinstance(pos, tuple):
                if len(pos) == 2:
                    # If no tree type specified, use a random one
                    x, y = pos
                    tree_type = random.choice(['tree1', 'tree2', 'tree3'])
                    all_decorations.append(('tree', (x, y, tree_type), y))
                else:
                    # Tree type is specified
                    x, y, tree_type = pos
                    all_decorations.append(('tree', (x, y, tree_type), y))
                    
        # Sort all decorations by y-coordinate
        all_decorations.sort(key=lambda x: x[2])
        
        # Draw all decorations in sorted order
        for dec_type, pos, _ in all_decorations:
            if dec_type == 'building':
                self.draw_building(screen, (pos[0], pos[1]), pos[2])
            elif dec_type == 'tree':
                self.draw_tree(screen, (pos[0], pos[1]), pos[2])
            
    def draw_building(self, screen, pos, building_type):
        """Draw a building at the specified position"""
        if building_type in self.building_images:
            img = self.building_images[building_type]
            # Draw building centered at position
            rect = img.get_rect(midbottom=(pos[0], pos[1]))
            screen.blit(img, rect)

    def draw_tree(self, screen, pos, tree_type):
        """Draw a tree at the specified position with the specified type"""
        if tree_type in self.tree_images:
            tree_img = self.tree_images[tree_type]
            # Draw tree centered at position
            rect = tree_img.get_rect(midbottom=pos)
            screen.blit(tree_img, rect)

    def start_wave(self, wave_number):
        """Start a new wave with appropriate difficulty scaling"""
        self.current_wave = wave_number
        self.wave_in_progress = True
        self.next_wave_ready = False
        self.enemy_spawn_timer = pygame.time.get_ticks() / 1000
        self.wave_timer = self.enemy_spawn_timer
        
        # Adjust spawn delay based on wave number
        self.spawn_delay = max(0.3, 1.0 - (self.current_wave * 0.02))
        
        if self.is_boss_wave():
            self.enemies_to_spawn = 1
            self.spawn_boss()
        else:
            self.enemies_to_spawn = self.calculate_wave_size()
            self.enemy_types = self.determine_enemy_types()

    def spawn_wave(self):
        """Generate enemies for the current wave"""
        if self.enemies_to_spawn > 0:
            enemy_type = random.choice(self.enemy_types)
            enemy = Enemy(enemy_type, self.path, self.current_wave)
            self.scale_enemy_stats(enemy)
            self.enemy_manager.spawn_enemy(enemy)
            self.enemies_to_spawn -= 1

    def calculate_wave_size(self):
        """Calculate number of enemies for current wave"""
        if self.current_wave == 1:
            return 5  # Fixed size for first wave
        
        # Random size for subsequent waves with steady increase
        base_size = 5 + int(self.current_wave * 1.2)  # More enemies per wave
        variation = random.randint(-2, min(4, self.current_wave))  # More variation in later waves
        return max(5, base_size + variation)

    def determine_enemy_types(self):
        """Determine which enemy types can appear in current wave"""
        if self.current_wave == 1:
            return ['normal']  # First wave is normal enemies only
            
        available_types = ['normal']
        
        # Add armored enemies more gradually
        if self.current_wave >= 3:
            available_types.append('armored')
            
        # Add fast enemies after a few waves
        if self.current_wave >= 4:
            available_types.append('fast')
            
        # Randomize enemy type distribution with weighted probabilities
        weights = []
        for enemy_type in available_types:
            if enemy_type == 'normal':
                weight = max(30, 100 - self.current_wave * 3)  # Decreasing weight for normal enemies
            elif enemy_type == 'armored':
                weight = min(50, self.current_wave * 2)  # Increasing weight for armored
            else:  # fast
                weight = min(40, self.current_wave * 2)  # Increasing weight for fast
            weights.append(weight)
            
        # Normalize weights and select enemies
        total = sum(weights)
        weights = [w/total for w in weights]
        choices = random.choices(available_types, weights=weights, k=min(5, self.current_wave))
        return list(set(choices))  # Remove duplicates

    def scale_enemy_stats(self, enemy):
        """Scale enemy stats based on wave number"""
        if self.current_wave == 1:
            # First wave: enemies are at base stats
            enemy.stats['health'] *= 0.75  # Even easier first wave
            return

        # Calculate exponential scaling factor
        base_multiplier = 1.15  # 15% base increase
        wave_exp = (self.current_wave - 1) / 10  # Exponential growth factor
        wave_factor = base_multiplier ** wave_exp
        
        # Add random variation
        random_factor = random.uniform(0.95, 1.05)  # ±5% random variation
        
        # Apply scaling
        enemy.stats['health'] *= wave_factor * random_factor
        
        # Gold scales more linearly to keep economy balanced
        gold_factor = 1 + (self.current_wave - 1) * 0.15  # Increased gold scaling
        enemy.stats['gold_value'] = int(enemy.stats['gold_value'] * gold_factor)

    def is_boss_wave(self):
        return self.current_wave % 10 == 0
        
    def spawn_boss(self):
        """Spawn a boss enemy"""
        boss_type = 'normal'  # Base boss type
        multiplier = BOSS_STATS_MULTIPLIER
        
        # Special bosses for waves 50 and 100
        if self.current_wave == 50:
            multiplier *= 2
        elif self.current_wave == 100:
            multiplier = MEGA_BOSS_MULTIPLIER
            
        # Create a boss enemy with scaled stats
        enemy = Enemy(boss_type, self.path, self.current_wave)
        enemy.stats['health'] *= multiplier
        enemy.stats['gold_value'] *= multiplier
        enemy.radius *= 1.5  # Make boss visually larger
        
        self.enemy_manager.spawn_enemy(enemy)

    def update_wave_timer(self, dt):
        """Update the wave timer and countdown"""
        if self.wave_in_progress:
            # Check if wave is halfway through
            if not self.wave_halfway and len(self.enemy_manager.enemies) <= self.enemies_to_spawn / 2:
                self.wave_halfway = True
                self.start_countdown()
            
            # Check if all enemies are defeated
            if len(self.enemy_manager.enemies) == 0 and self.enemies_to_spawn == 0:
                self.wave_in_progress = False
                self.wave_halfway = False
                self.start_countdown()
                
        if self.countdown_active:
            self.countdown_timer -= dt
            if self.countdown_timer <= 0:
                self.countdown_active = False
                if not self.wave_in_progress:
                    self.start_next_wave()

    def start_countdown(self):
        """Start the countdown timer"""
        self.countdown_active = True
        self.countdown_timer = self.countdown_duration

    def draw_timer(self, screen):
        """Draw the wave timer and countdown"""
        # Always draw wave number
        wave_text = f"Wave {self.current_wave}"
        wave_surface = self.font.render(wave_text, True, (255, 255, 255))
        wave_rect = wave_surface.get_rect()
        wave_rect.centerx = screen.get_width() // 2
        wave_rect.top = 10
        screen.blit(wave_surface, wave_rect)
        
        # Second line for wave status and time
        if self.countdown_active:
            timer_text = f"Next wave in: {max(0, self.countdown_timer):.1f}s"
        elif self.wave_in_progress:
            remaining_enemies = self.enemies_to_spawn + len(self.enemy_manager.enemies)
            timer_text = f"Wave in Progress - {remaining_enemies} enemies remaining"
        else:
            timer_text = "Preparing next wave..."
            
        # Render status text
        text_surface = self.font.render(timer_text, True, (255, 255, 255))
        text_rect = text_surface.get_rect()
        text_rect.centerx = screen.get_width() // 2
        text_rect.top = wave_rect.bottom + 5
        screen.blit(text_surface, text_rect)

    def update(self, dt):
        """Update the wave manager"""
        self.update_wave_timer(dt)
        
        if self.wave_in_progress and self.enemies_to_spawn > 0:
            self.enemy_spawn_timer -= dt
            if self.enemy_spawn_timer <= 0:
                self.spawn_wave()
                self.enemy_spawn_timer = self.spawn_delay

    def is_wave_complete(self):
        """Check if the current wave is complete"""
        return not self.wave_in_progress and self.current_wave > 0

    def start_next_wave(self):
        """Start the next wave with appropriate difficulty scaling"""
        self.current_wave += 1  # Increment wave number
        self.wave_in_progress = True
        self.enemy_spawn_timer = pygame.time.get_ticks() / 1000
        
        # Adjust spawn delay based on wave number
        self.spawn_delay = max(0.3, 1.0 - (self.current_wave * 0.02))
        
        if self.is_boss_wave():
            # Boss waves have fewer but stronger enemies
            self.enemies_to_spawn = 1
            self.spawn_boss()
        else:
            # Regular waves scale with wave number
            self.enemies_to_spawn = self.calculate_wave_size()
            self.enemy_types = self.determine_enemy_types()

    def prepare_next_wave(self, wave_number):
        """Prepare the next wave of enemies"""
        self.current_wave = wave_number
        self.wave_timer = pygame.time.get_ticks() / 1000  # Start countdown to next wave
        self.enemies_to_spawn = self.calculate_wave_size()
        self.enemy_types = self.determine_enemy_types()
        
        # Add gems for completing the wave
        if wave_number > 1:  # Don't give gems for the first wave
            gem_reward = self.calculate_gem_reward(wave_number - 1)  # Previous wave
            self.enemy_manager.gems_earned += gem_reward
    
    def calculate_gem_reward(self, wave_number):
        """Calculate gems earned for completing a wave"""
        if wave_number == 100:
            return 25  # Special reward for wave 100
        elif wave_number == 50:
            return 10  # Special reward for wave 50
        elif wave_number == 25:
            return 5   # Special reward for wave 25
        elif wave_number > 0:            # Small chance for bonus gems on other waves
            if random.random() < 0.1:  # 10% chance
                return random.randint(1, 3)
        return 0

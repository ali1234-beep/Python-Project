import pygame
import math
from .constants import *

class Projectile:
    def __init__(self, start_pos, target, damage, damage_type, speed=300):
        self.position = pygame.Vector2(start_pos)
        self.target = target
        self.damage = damage
        self.damage_type = damage_type
        self.speed = speed
        self.is_active = True
        self.recalculate_direction()
        
    def recalculate_direction(self):
        # Always update direction to track target (homing projectile)
        direction = pygame.Vector2(self.target.position) - pygame.Vector2(self.position)
        if direction.length() > 0:
            direction.normalize_ip()
            self.velocity = direction * self.speed
            self.angle = math.degrees(math.atan2(-direction.y, direction.x))
        
    def update(self, dt):
        if not self.is_active or not self.target:
            return False
            
        # Always recalculate direction to perfectly track target
        self.recalculate_direction()
        self.position += self.velocity * dt
        
        # Check if hit target
        if pygame.Vector2(self.position).distance_to(self.target.position) < 10:
            self.target.take_damage(self.damage, self.damage_type)
            return False
            
        return True
        
    def draw(self, screen):
        if self.damage_type == 'ranged':  # Arrow
            # Create arrow surface
            arrow_length = 20
            arrow_surface = pygame.Surface((arrow_length, 6), pygame.SRCALPHA)
            
            # Draw arrow shaft
            pygame.draw.line(arrow_surface, (139, 69, 19), (0, 3), (arrow_length-5, 3), 2)
            # Draw arrowhead
            pygame.draw.polygon(arrow_surface, (139, 69, 19), 
                              [(arrow_length-5, 0), (arrow_length, 3), (arrow_length-5, 6)])
            
            # Rotate arrow
            rotated = pygame.transform.rotate(arrow_surface, self.angle)
            screen.blit(rotated, (self.position.x - rotated.get_width()//2,
                                self.position.y - rotated.get_height()//2))
                                
        elif self.damage_type == 'magic':  # Magical projectile
            # Create magical orb with trail
            orb_radius = 8
            trail_length = 4
            
            # Draw magical trail
            for i in range(trail_length):
                trail_pos = self.position - self.velocity.normalize() * (i * 5)
                trail_radius = orb_radius * (1 - i/trail_length)
                trail_alpha = 255 * (1 - i/trail_length)
                
                # Create surface for trail particle
                trail_surface = pygame.Surface((trail_radius * 2 + 4, trail_radius * 2 + 4), pygame.SRCALPHA)
                
                # Draw purple magical trail with fade
                pygame.draw.circle(trail_surface, (160, 32, 240, trail_alpha), 
                                 (trail_radius + 2, trail_radius + 2), trail_radius)
                
                screen.blit(trail_surface, 
                           (trail_pos.x - trail_radius - 2, trail_pos.y - trail_radius - 2))
            
            # Draw main magical orb
            orb_surface = pygame.Surface((orb_radius * 2 + 4, orb_radius * 2 + 4), pygame.SRCALPHA)
            
            # Draw outer glow
            pygame.draw.circle(orb_surface, (180, 0, 255, 128), 
                             (orb_radius + 2, orb_radius + 2), orb_radius + 2)
            # Draw core
            pygame.draw.circle(orb_surface, (255, 255, 255), 
                             (orb_radius + 2, orb_radius + 2), orb_radius - 2)
            
            screen.blit(orb_surface, 
                       (self.position.x - orb_radius - 2, self.position.y - orb_radius - 2))

class Tower:
    # Target mode constants
    TARGET_FIRST = 'first'
    TARGET_LAST = 'last'
    TARGET_STRONGEST = 'strongest'
    
    def __init__(self, position, tower_type):
        self.position = position
        self.type = tower_type
        self.level = 1
        self.projectiles = []
        self.radius = 20  # Base tower radius
        self.target_mode = Tower.TARGET_FIRST  # Default targeting mode
        
        # Set tower attributes based on type
        tower_data = TOWER_TYPES[tower_type]
        self.range = tower_data['range']
        self.damage = tower_data['damage']
        self.attack_speed = tower_data['attack_speed']
        self.cost = tower_data['cost']
        self.last_attack = 0
        self.attack_cooldown = 1000 / self.attack_speed  # Convert to milliseconds
        
    def cycle_target_mode(self):
        """Cycle through available targeting modes"""
        if self.target_mode == Tower.TARGET_FIRST:
            self.target_mode = Tower.TARGET_STRONGEST
        elif self.target_mode == Tower.TARGET_STRONGEST:
            self.target_mode = Tower.TARGET_LAST
        else:
            self.target_mode = Tower.TARGET_FIRST
        return self.target_mode
        
    def update(self, dt, enemies):
        # Update projectiles
        self.projectiles = [p for p in self.projectiles if p.update(dt)]
        
        # Check for attack
        current_time = pygame.time.get_ticks()
        if current_time - self.last_attack >= self.attack_cooldown:
            target = self.find_target(enemies)
            if target:
                self.attack(target)
                self.last_attack = current_time
                
    def find_target(self, enemies):
        if not enemies:
            return None
            
        in_range_enemies = [e for e in enemies if pygame.Vector2(e.position).distance_to(self.position) <= self.range]
        if not in_range_enemies:
            return None
            
        if self.target_mode == Tower.TARGET_FIRST:
            # Target enemy that's furthest along the path
            return max(in_range_enemies, key=lambda e: e.distance_traveled)
        elif self.target_mode == Tower.TARGET_LAST:
            # Target enemy that's least along the path
            return min(in_range_enemies, key=lambda e: e.distance_traveled)
        else:  # TARGET_STRONGEST
            # Target enemy with highest health            return max(in_range_enemies, key=lambda e: e.health)
            
    def attack(self, target):
        if self.type == 'archer':
            projectile = Projectile(self.position, target, self.damage, 'ranged', speed=400)  # Faster projectiles
            self.projectiles.append(projectile)
        elif self.type == 'mage':
            projectile = Projectile(self.position, target, self.damage, 'magic', speed=300)  # Magical projectile
            self.projectiles.append(projectile)
        else:  # warrior
            # Instant damage for melee attacks
            target.take_damage(self.damage, 'melee')
            
    def draw(self, screen, is_selected=False):        # Draw tower base with stone texture
        base_color = (85, 75, 65)  # Stone color
        pygame.draw.circle(screen, base_color, self.position, self.radius)
        pygame.draw.circle(screen, (65, 55, 45), self.position, self.radius - 2)  # Inner shadow
        
        # Draw tower top based on type
        if self.type == 'archer':
            # Draw wooden bow
            bow_color = (101, 67, 33)  # Dark wood brown
            bow_radius = 15
            bow_thickness = 3
            pygame.draw.arc(screen, bow_color, 
                          (self.position[0] - bow_radius, self.position[1] - bow_radius,
                           bow_radius * 2, bow_radius * 2),
                           math.pi/4, math.pi*7/4, bow_thickness)
            # Bowstring
            pygame.draw.line(screen, (210, 200, 180),  # Pale string color
                           (self.position[0] - 10, self.position[1]),
                           (self.position[0] + 10, self.position[1]), 1)
        elif self.type == 'warrior':
            # Draw iron sword
            sword_color = (130, 120, 110)  # Aged iron color
            handle_color = (80, 50, 20)  # Dark leather brown
            # Blade
            pygame.draw.line(screen, sword_color,
                           (self.position[0], self.position[1] - 15),
                           (self.position[0], self.position[1] + 15), 4)
            # Handle
            pygame.draw.line(screen, handle_color,
                           (self.position[0] - 8, self.position[1]),
                           (self.position[0] + 8, self.position[1]), 6)
        elif self.type == 'mage':
            # Draw wooden staff with magical orb
            staff_color = (90, 60, 30)  # Dark wood
            orb_color = (120, 80, 160)  # Mystical purple
            # Staff
            pygame.draw.line(screen, staff_color,
                           (self.position[0], self.position[1] - 20),
                           (self.position[0], self.position[1] + 10), 3)
            # Glowing orb
            pygame.draw.circle(screen, orb_color,
                            (self.position[0], self.position[1] - 20), 6)
            pygame.draw.circle(screen, (180, 140, 220),  # Lighter inner glow
                            (self.position[0], self.position[1] - 20), 4)
                            
        # Draw projectiles
        for projectile in self.projectiles:
            projectile.draw(screen)
            
        # Only draw range circle when selected
        if is_selected:
            range_surface = pygame.Surface((self.range * 2, self.range * 2), pygame.SRCALPHA)
            pygame.draw.circle(range_surface, (255, 255, 255, 30), 
                             (self.range, self.range), self.range)
            screen.blit(range_surface, 
                       (self.position[0] - self.range, self.position[1] - self.range))
                   
    def get_upgrade_cost(self, attribute):
        """Calculate cost to upgrade an attribute"""
        base_cost = self.cost * 0.5  # 50% of initial tower cost
        level_multiplier = 1.5 ** (self.level - 1)
        return int(base_cost * level_multiplier)
        
    def upgrade(self, attribute):
        """Upgrade a tower's attribute"""
        if attribute == 'range':
            self.range *= 1.2
        elif attribute == 'damage':
            self.damage *= 1.3
        elif attribute == 'attack_speed':
            self.attack_speed *= 1.2
            self.attack_cooldown = 1000 / self.attack_speed
            
        self.level += 1
          def get_sell_value(self):
        """Calculate the sell value of the tower"""
        return int(self.cost * TOWER_SELL_RATIO)  # 35% of purchase cost
import pygame
from .constants import *

class EnemyManager:
    def __init__(self):
        self.enemies = []
        self.gems_earned = 0
        self.lives = 20  # Player starts with 20 lives
        self.game_state = None  # Will be set by GameState
        
    def spawn_enemy(self, enemy):
        self.enemies.append(enemy)
        
    def update(self):
        # Update each enemy and remove dead ones
        remaining_enemies = []
        for enemy in self.enemies:
            reached_end = enemy.move()
            
            if reached_end:
                # Enemy reached the end - damage base
                self.game_state.damage_base(1)  # Each enemy does 1 damage
                continue
                
            if enemy.health > 0:
                remaining_enemies.append(enemy)
            else:
                # Enemy died - award gold
                self.game_state.currency_manager.add_gold(enemy.stats['gold_value'])
                
        self.enemies = remaining_enemies
        
    def is_wave_complete(self):
        return len(self.enemies) == 0
        
    def calculate_gem_reward(self, wave_number):
        """Calculate gems earned for completing a wave"""
        if wave_number == 100:
            return 25
        elif wave_number > 0:
            # Scale gems from 1 to 24 based on wave number
            return max(1, int((wave_number / 100) * 24))
        return 0
        
    def draw(self, screen):
        for enemy in self.enemies:
            enemy.draw(screen)

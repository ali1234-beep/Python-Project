import pygame
import random
from .wave_manager import WaveManager
from .tower_manager import TowerManager
from .enemy_manager import EnemyManager
from .ui_manager import UIManager
from .currency_manager import CurrencyManager
from .constants import *

class GameState:
    def __init__(self):
        self.is_game_started = False
        self.current_wave = 0
        self.is_endless_mode = False
        self.is_paused = False
        self.show_settings = False
        self.base_health = BASE_MAX_HEALTH
        
        # Initialize settings with defaults
        self.settings = DEFAULT_SETTINGS.copy()
        
        # Initialize managers
        self.currency_manager = CurrencyManager()
        self.enemy_manager = EnemyManager()
        self.enemy_manager.game_state = self
        self.tower_manager = TowerManager(self.currency_manager)
        self.wave_manager = WaveManager(self.enemy_manager)
        self.ui_manager = UIManager(self)
          # Load and prepare grass textures
        try:
            grass_texture = pygame.image.load('Assets/SeamlessGroundTextures09012024/SeamlessGroundTextures/assets2Ftask_01jsjahz8sf8jsfasz00kjxjkw2Fimg_0.png').convert_alpha()
        except pygame.error:
            # Try alternate path with backslashes for Windows
            grass_texture = pygame.image.load(r'Assets\SeamlessGroundTextures09012024\SeamlessGroundTextures\assets2Ftask_01jsjahz8sf8jsfasz00kjxjkw2Fimg_0.png').convert_alpha()
        # Scale down the grass texture to create a tiled effect
        scale = 0.08  # Make tiles much smaller for more detailed tiling
        self.grass_tile = pygame.transform.scale(
            grass_texture, 
            (int(grass_texture.get_width() * scale), 
             int(grass_texture.get_height() * scale))
        )
        
        # Calculate how many tiles we need to fill the screen
        self.grass_tiles_x = SCREEN_WIDTH // self.grass_tile.get_width() + 2
        self.grass_tiles_y = SCREEN_HEIGHT // self.grass_tile.get_height() + 2
        
        # Create a surface for the background
        self.background = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.create_background()
        
        # Connect managers
        self.tower_manager.enemy_manager = self.enemy_manager

    def create_background(self):
        """Create the tiled grass background"""
        # Fill with a base color first
        self.background.fill((34, 139, 34))  # Forest green base
        
        # Create a consistent grid of grass tiles
        for y in range(self.grass_tiles_y):
            for x in range(self.grass_tiles_x):
                # Calculate position
                pos_x = x * self.grass_tile.get_width()
                pos_y = y * self.grass_tile.get_height()
                
                # Draw the grass tile without rotation
                self.background.blit(self.grass_tile, (pos_x, pos_y))
        
        # Apply a slight transparency to blend with base color
        self.background.set_alpha(180)

    def start_game(self):
        self.is_game_started = True
        self.current_wave = 1
        self.wave_manager.start_wave(self.current_wave)

    def toggle_pause(self):
        self.is_paused = not self.is_paused
        self.show_settings = False

    def toggle_settings(self):
        self.show_settings = not self.show_settings

    def update_setting(self, setting_name, value):
        if setting_name in self.settings:
            self.settings[setting_name] = value

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            # All UI interactions including tower placement are handled in UI manager
            self.ui_manager.handle_event(event.pos, event.button)

    def update(self):
        if not self.is_game_started or self.is_paused:
            # Only update UI when paused
            self.ui_manager.update()
            return

        self.tower_manager.update()
        self.enemy_manager.update()
        self.wave_manager.update()
        self.ui_manager.update()

        # Check if wave is complete
        if self.wave_manager.is_wave_complete():
            self.handle_wave_completion()

    def handle_wave_completion(self):
        next_wave = self.current_wave + 1
        if next_wave > 100 and not self.is_endless_mode:
            self.ui_manager.show_game_complete_menu()
        elif self.wave_manager.next_wave_ready:
            self.wave_manager.start_wave(next_wave)
            self.current_wave = next_wave

    def enter_endless_mode(self):
        self.is_endless_mode = True
        self.current_wave = 101

    def damage_base(self, amount):
        self.base_health = max(0, self.base_health - amount)
        if self.base_health <= 0:
            self.game_over()

    def game_over(self):
        self.is_game_started = False
        self.ui_manager.show_game_over_menu()

    def draw(self, screen):
        """Draw all game elements"""
        # Draw the background first
        screen.blit(self.background, (0, 0))
        
        # Draw the path after background but before other elements
        self.wave_manager.draw_path(screen)
        
        # Draw decorations after path
        self.wave_manager.draw_decorations(screen)
        
        # Draw remaining game elements
        self.tower_manager.draw(screen)
        self.enemy_manager.draw(screen)
        self.ui_manager.draw(screen)

import pygame
import sys
from game.game_state import GameState
from game.constants import *

class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("Medieval Tower Defense")
        self.clock = pygame.time.Clock()
        self.game_state = GameState()

    def run(self):
        while True:
            # Event handling
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                self.game_state.handle_event(event)

            # Update game state
            self.game_state.update()

            # Draw everything
            self.screen.fill(BACKGROUND_COLOR)
            self.game_state.draw(self.screen)
            pygame.display.flip()

            # Cap the frame rate
            self.clock.tick(FPS)

if __name__ == "__main__":
    game = Game()
    game.run()

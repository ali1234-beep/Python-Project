using UnityEngine;
using System.Collections.Generic;

public class Enemy : MonoBehaviour
{
    [Header("Base Stats")]
    public float maxHealth = 100f;
    public float moveSpeed = 2f;
    public int goldValue = 10;
    
    [Header("Resistance Types")]
    public float meleeResistance = 1f;
    public float rangedResistance = 1f;
    public float magicResistance = 1f;
    
    protected float currentHealth;
    protected List<Vector3> pathPoints;
    protected int currentPathIndex;

    protected virtual void Start()
    {
        currentHealth = maxHealth;
        // Initialize path points from WaveManager
        pathPoints = WaveManager.Instance.GetPathPoints();
        currentPathIndex = 0;
        transform.position = pathPoints[0];
    }

    protected virtual void Update()
    {
        Move();
    }

    protected virtual void Move()
    {
        if (currentPathIndex >= pathPoints.Count)
            return;

        Vector3 targetPoint = pathPoints[currentPathIndex];
        transform.position = Vector3.MoveTowards(transform.position, targetPoint, moveSpeed * Time.deltaTime);

        if (Vector3.Distance(transform.position, targetPoint) < 0.1f)
        {
            currentPathIndex++;
            if (currentPathIndex >= pathPoints.Count)
            {
                ReachedEnd();
            }
        }
    }

    public virtual void TakeDamage(float damage, string damageType)
    {
        float finalDamage = damage;
        switch (damageType.ToLower())
        {
            case "melee":
                finalDamage *= meleeResistance;
                break;
            case "ranged":
                finalDamage *= rangedResistance;
                break;
            case "magic":
                finalDamage *= magicResistance;
                break;
        }

        currentHealth -= finalDamage;
        if (currentHealth <= 0)
        {
            Die();
        }
    }

    protected virtual void Die()
    {
        GameManager.Instance.AddGold(goldValue);
        Destroy(gameObject);
    }

    protected virtual void ReachedEnd()
    {
        // Implement health reduction logic here
        Destroy(gameObject);
    }
}

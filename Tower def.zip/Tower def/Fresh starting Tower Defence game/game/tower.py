import pygame
import math
import random
from .constants import *
from .projectile import Projectile, ChainLightning, Bomb

class Projectile:
    def __init__(self, start_pos, target, damage, damage_type, speed=300, angle_offset=0, armor_pierce=False, mana_burn=False):
        self.position = pygame.Vector2(start_pos)
        self.target = target
        self.damage = damage
        self.damage_type = damage_type
        self.speed = speed
        self.is_active = True
        self.armor_pierce = armor_pierce
        self.mana_burn = mana_burn
        
        # Calculate direction to target with optional angle offset
        direction = pygame.Vector2(target.position) - pygame.Vector2(start_pos)
        if direction.length() > 0:
            direction.normalize_ip()
            # Apply angle offset
            if angle_offset != 0:
                angle = math.atan2(direction.y, direction.x)
                angle += math.radians(angle_offset)
                direction.x = math.cos(angle)
                direction.y = math.sin(angle)
            self.velocity = direction * speed
            self.angle = math.degrees(math.atan2(-direction.y, direction.x))

    def update(self, dt):
        if not self.is_active or not self.target:
            return False
            
        # Move towards target
        self.position += self.velocity * dt
        
        # Check if hit target
        if pygame.Vector2(self.position).distance_to(self.target.position) < 10:
            # Apply effects on hit
            if self.mana_burn:
                # Deal bonus damage based on target's shield/mana if any
                bonus_damage = min(self.target.shield, self.damage)
                self.target.shield = max(0, self.target.shield - self.damage)
                self.damage += bonus_damage
            
            self.target.take_damage(self.damage, self.damage_type, ignore_armor=self.armor_pierce)
            return False
            
        return True
        
    def draw(self, screen):
        if self.damage_type == 'ranged':  # Arrow
            # Create arrow surface
            arrow_length = 20
            arrow_surface = pygame.Surface((arrow_length, 6), pygame.SRCALPHA)
            
            # Draw arrow shaft
            pygame.draw.line(arrow_surface, (139, 69, 19), (0, 3), (arrow_length-5, 3), 2)
            # Draw arrowhead
            pygame.draw.polygon(arrow_surface, (139, 69, 19), 
                              [(arrow_length-5, 0), (arrow_length, 3), (arrow_length-5, 6)])
            
            # Rotate arrow
            rotated = pygame.transform.rotate(arrow_surface, self.angle)
            screen.blit(rotated, (self.position.x - rotated.get_width()//2,
                                self.position.y - rotated.get_height()//2))
                                
        elif self.damage_type == 'magic':  # Magical projectile
            # Create magical orb with trail
            orb_radius = 8
            trail_length = 4
            
            # Draw magical trail
            for i in range(trail_length):
                trail_pos = self.position - self.velocity.normalize() * (i * 5)
                trail_radius = orb_radius * (1 - i/trail_length)
                trail_alpha = 255 * (1 - i/trail_length)
                
                # Create surface for trail particle
                trail_surface = pygame.Surface((trail_radius * 2 + 4, trail_radius * 2 + 4), pygame.SRCALPHA)
                
                # Draw purple magical trail with fade
                pygame.draw.circle(trail_surface, (160, 32, 240, trail_alpha), 
                                 (trail_radius + 2, trail_radius + 2), trail_radius)
                
                screen.blit(trail_surface, 
                           (trail_pos.x - trail_radius - 2, trail_pos.y - trail_radius - 2))
            
            # Draw main magical orb
            orb_surface = pygame.Surface((orb_radius * 2 + 4, orb_radius * 2 + 4), pygame.SRCALPHA)
            
            # Draw outer glow
            pygame.draw.circle(orb_surface, (180, 0, 255, 128), 
                             (orb_radius + 2, orb_radius + 2), orb_radius + 2)
            # Draw core
            pygame.draw.circle(orb_surface, (255, 255, 255), 
                             (orb_radius + 2, orb_radius + 2), orb_radius - 2)
            
            screen.blit(orb_surface, 
                       (self.position.x - orb_radius - 2, self.position.y - orb_radius - 2))

class Tower:
    # Target mode constants
    TARGET_FIRST = 'first'
    TARGET_LAST = 'last'
    TARGET_STRONGEST = 'strongest'
    
    def __init__(self, position, tower_type):
        self.position = pygame.Vector2(position)
        self.type = tower_type
        
        # Get base stats from shop data
        shop_data = TOWER_SHOP_DATA[tower_type]
        self.stats = {
            'damage': shop_data.get('damage', 30),
            'range': shop_data.get('range', 150),
            'attack_speed': shop_data.get('attack_speed', 1.0)
        }
        
        # Special abilities
        self.effects = {}  # Status effects the tower can apply
        self.chain_targets = 0  # For Tesla Coil
        self.chain_damage_reduction = 0.7
        self.splash_radius = 0  # For Bomb Lobber
        self.splash_damage_falloff = 0.5
        self.instant_kill_threshold = 0  # For Sniper
        self.gold_per_second = 0  # For Gold Golem
        
        self.target = None
        self.attack_timer = 0
        self.projectiles = []
        
    def find_targets(self, enemies):
        """Find all valid targets within range"""
        valid_targets = []
        
        for enemy in enemies:
            distance = pygame.math.Vector2(enemy.position).distance_to(self.position)
            if distance <= self.stats['range']:
                valid_targets.append((enemy, distance))
                
        # Sort by distance
        valid_targets.sort(key=lambda x: x[1])
        return valid_targets
        
    def attack(self, current_time, enemies):
        """Perform attack based on tower type"""
        if current_time < self.attack_timer:
            return
            
        # Reset attack timer
        self.attack_timer = current_time + (1.0 / self.stats['attack_speed'])
        
        valid_targets = self.find_targets(enemies)
        if not valid_targets:
            return
            
        damage = self.stats['damage']
        
        # Handle different tower types
        if self.chain_targets > 0:  # Tesla Coil
            targets = [t[0] for t in valid_targets[:self.chain_targets]]
            projectile = ChainLightning(
                self.position,
                targets,
                damage,
                self.chain_damage_reduction
            )
            self.projectiles.append(projectile)
            
        elif self.splash_radius > 0:  # Bomb Lobber
            primary_target = valid_targets[0][0]
            projectile = Bomb(
                self.position,
                primary_target,
                damage,
                self.splash_radius,
                self.splash_damage_falloff
            )
            self.projectiles.append(projectile)
            
        elif self.instant_kill_threshold > 0:  # Sniper
            target = valid_targets[0][0]
            # Sniper uses hitscan - no projectile
            if target.health <= self.instant_kill_threshold:
                target.take_damage(target.health, 'ranged')  # Instant kill
            else:
                target.take_damage(damage, 'ranged')
                
        else:  # Basic attack with possible effects
            target = valid_targets[0][0]
            projectile = Projectile(
                self.position,
                target,
                damage,
                'ranged' if self.type == 'basic_archer' else 'magic'
            )
            self.projectiles.append(projectile)
            
    def update(self, enemies):
        """Update tower state and perform attacks"""
        if not enemies:
            return
            
        current_time = pygame.time.get_ticks() / 1000.0
        self.attack(current_time, enemies)
        
        # Update any active projectiles
        for proj in self.projectiles[:]:
            if proj.update():
                self.projectiles.remove(proj)
                
    def draw(self, screen):
        """Draw the tower and its projectiles"""
        # Draw base tower
        color = TOWER_SHOP_DATA[self.type]['icon_color']
        pygame.draw.circle(screen, color, self.position, 15)
        
        # Draw range indicator if selected
        if hasattr(self, 'selected') and self.selected:
            pygame.draw.circle(screen, (255, 255, 255), self.position, 
                            self.stats['range'], 1)
                            
        # Draw projectiles
        for projectile in self.projectiles:
            projectile.draw(screen)
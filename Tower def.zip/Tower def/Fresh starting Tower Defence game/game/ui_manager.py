import pygame
import sys
import math
from .constants import *
from .medieval_theme import *  # Import medieval theme colors and constants
from .debug_log import log_debug

class UIManager:
    def __init__(self, game_state):
        self.game_state = game_state
        try:
            self.font = pygame.font.Font(None, 24)  # Regular font
            self.large_font = pygame.font.Font(None, 48)  # Larger font for start button
        except pygame.error as e:
            print(f"Error loading fonts: {e}")
            # Fallback to system default font
            self.font = pygame.font.SysFont('arial', 24)
            self.large_font = pygame.font.SysFont('arial', 48)
        self.selected_tower = None
        self.tower_menu_visible = False
        self.tower_preview = None  # Store preview tower
        self.pause_button = pygame.Rect(SCREEN_WIDTH - 50, 10, 40, 40)
        self.setup_ui_elements()
        self.setup_pause_menu()
        self.setup_settings_menu()
        self.slider_dragging = False
        
    def setup_ui_elements(self):
        # UI element sizes with better proportions
        button_size = 80  # Larger tower buttons
        button_spacing = 30  # More space between buttons
        bottom_margin = 40  # More space at bottom
        top_margin = 25
        
        # Calculate centered positions for tower buttons
        total_width = (button_size * 3) + (button_spacing * 2)
        start_x = (SCREEN_WIDTH - total_width) // 2
        
        # Create buttons with consistent styling
        self.buttons = {
            'start_game': pygame.Rect(SCREEN_WIDTH//2 - 250, SCREEN_HEIGHT//2 - 50, 500, 100),  # Bigger start button
            'tower_archer': pygame.Rect(start_x, 
                                      SCREEN_HEIGHT - button_size - bottom_margin, 
                                      button_size, button_size),
            'tower_warrior': pygame.Rect(start_x + button_size + button_spacing, 
                                       SCREEN_HEIGHT - button_size - bottom_margin, 
                                       button_size, button_size),
            'tower_mage': pygame.Rect(start_x + (button_size + button_spacing) * 2, 
                                    SCREEN_HEIGHT - button_size - bottom_margin, 
                                    button_size, button_size),
        }
        
        # Upgrade menu buttons with consistent sizing
        menu_padding = 12
        button_height = 35  # Taller buttons for better visibility
        button_width = 176  # Width that fits nicely in the menu
        button_spacing = 8  # Space between buttons
        
        self.upgrade_buttons = {
            'range': pygame.Rect(0, 0, button_width, button_height),
            'damage': pygame.Rect(0, button_height + button_spacing, 
                                button_width, button_height),
            'attack_speed': pygame.Rect(0, (button_height + button_spacing) * 2, 
                                      button_width, button_height),
            'sell': pygame.Rect(0, (button_height + button_spacing) * 3 + button_spacing, 
                              button_width, button_height)  # Extra spacing before sell button
        }
        
        # Status bar rects
        status_height = 40
        self.status_rects = {
            'wave': pygame.Rect(SCREEN_WIDTH//2 - 100, top_margin, 200, status_height),
            'countdown': pygame.Rect(SCREEN_WIDTH//2 - 60, top_margin + status_height + 5, 
                                   120, status_height//2)
        }
        
    def setup_pause_menu(self):
        center_x = SCREEN_WIDTH // 2
        center_y = SCREEN_HEIGHT // 2
        button_width = 200
        button_height = 50
        spacing = 20

        self.pause_menu_buttons = {
            'resume': pygame.Rect(center_x - button_width//2, center_y - button_height - spacing, 
                                button_width, button_height),
            'settings': pygame.Rect(center_x - button_width//2, center_y, 
                                  button_width, button_height),
            'quit': pygame.Rect(center_x - button_width//2, center_y + button_height + spacing, 
                              button_width, button_height)
        }

    def setup_settings_menu(self):
        center_x = SCREEN_WIDTH // 2
        start_y = SCREEN_HEIGHT // 4
        width = 300
        height = 50  # Increased height for better clickability
        spacing = 80  # Increased spacing between elements
        label_offset = 35  # Increased space for labels

        # Create sliders and checkboxes for settings
        self.settings_elements = {
            'volume': {
                'rect': pygame.Rect(center_x - width//2, start_y, width, height),
                'type': 'slider',
                'value': self.game_state.settings['volume']
            },
            'show_health_bars': {
                'rect': pygame.Rect(center_x - width//2, start_y + spacing, width, height),
                'type': 'checkbox',
                'value': self.game_state.settings['show_health_bars']
            },
            'show_damage_numbers': {
                'rect': pygame.Rect(center_x - width//2, start_y + spacing * 2, width, height),
                'type': 'checkbox',
                'value': self.game_state.settings['show_damage_numbers']
            },
            'show_tower_ranges': {
                'rect': pygame.Rect(center_x - width//2, start_y + spacing * 3, width, height),
                'type': 'checkbox',
                'value': self.game_state.settings['show_tower_ranges']
            },
            'background_animations': {
                'rect': pygame.Rect(center_x - width//2, start_y + spacing * 4, width, height),
                'type': 'checkbox',
                'value': self.game_state.settings['background_animations']
            }
        }

        # Back button with more space from settings
        self.settings_back = pygame.Rect(center_x - 100, start_y + spacing * 5 + 20, 200, height)

    def handle_click(self, pos):
        if not self.game_state.is_game_started:
            if self.buttons['start_game'].collidepoint(pos):
                self.game_state.start_game()
                return
        
        if self.tower_menu_visible:
            self.handle_tower_menu_click(pos)
        else:
            self.handle_game_click(pos)
            
    def handle_tower_menu_click(self, pos):
        """Handle clicks in the tower upgrade menu"""
        if self.selected_tower:
            # Check target mode button first
            if hasattr(self, 'target_mode_button') and self.target_mode_button.collidepoint(pos):
                new_mode = self.selected_tower.cycle_target_mode()
                return
                
            # Handle upgrade buttons
            for attribute, button in self.upgrade_buttons.items():
                if button.collidepoint(pos):
                    if attribute == 'sell':
                        self.game_state.tower_manager.sell_tower(self.selected_tower)
                        self.selected_tower = None
                        self.tower_menu_visible = False
                    else:
                        self.game_state.tower_manager.upgrade_tower(self.selected_tower, attribute)
                    return
          # Click outside menu closes it
        self.selected_tower = None
        self.tower_menu_visible = False
        
    def handle_game_click(self, pos):
        """Handle clicks during gameplay"""
        if not isinstance(pos, tuple) or not all(isinstance(coord, (int, float)) for coord in pos):
            log_debug(f"Invalid position received: {pos}")
            return
            
        # Convert position to tuple for consistency
        pos = (int(float(pos[0])), int(float(pos[1])))

        # Check if click is in bottom UI area first
        if pos[1] > SCREEN_HEIGHT - BOTTOM_BAR_HEIGHT:
            # Handle bottom UI clicks (tower buttons)
            for tower_type, button in self.buttons.items():
                if tower_type.startswith('tower_') and button.collidepoint(pos):
                    tower_name = tower_type.split('_')[1]
                    if tower_name in TOWER_TYPES and self.game_state.currency_manager.can_spend(TOWER_TYPES[tower_name]['cost']):
                        self.selected_tower_type = tower_name
                        # Create preview tower
                        self.tower_preview = {
                            'type': tower_name,
                            'range': TOWER_TYPES[tower_name]['range']
                        }
                    return
            # Clear preview if clicking in bottom UI but not on tower button
            if hasattr(self, 'selected_tower_type'):
                delattr(self, 'selected_tower_type')
                self.tower_preview = None
            return

        # If we have a selected tower type and click is in placement area, try to place tower
        if hasattr(self, 'selected_tower_type'):
            if self.is_valid_placement_area(pos):
                # Try to place the tower
                if self.game_state.tower_manager.try_place_tower(pos, self.selected_tower_type):
                    delattr(self, 'selected_tower_type')
                    self.tower_preview = None
            else:
                # Clear preview if clicking outside valid placement area
                delattr(self, 'selected_tower_type')
                self.tower_preview = None
            return

        # Check for clicks on existing towers (only if not trying to place a new tower)
        clicked_tower = self.game_state.tower_manager.select_tower(pos)
        if clicked_tower:
            self.selected_tower = clicked_tower
            self.tower_menu_visible = True
            self.position_upgrade_menu(clicked_tower.position)
            return
                
    def is_valid_placement_area(self, pos):
        """Check if the position is in a valid tower placement area"""
        return (pos[1] > MARGIN * 2 and  # Below top UI
                pos[1] < SCREEN_HEIGHT - MARGIN * 1.5 and  # Above bottom UI
                pos[0] > MARGIN and  # Right of left margin
                pos[0] < SCREEN_WIDTH - MARGIN)  # Left of right margin
                
    def position_upgrade_menu(self, tower_pos):
        """Position the upgrade menu next to the tower"""
        menu_x = tower_pos[0] + 50
        menu_y = tower_pos[1] - 60
        
        # Ensure menu stays within screen bounds
        if menu_x + 140 > SCREEN_WIDTH:  # If too far right
            menu_x = tower_pos[0] - 190
        if menu_y < MARGIN:  # If too high
            menu_y = MARGIN
        elif menu_y + 170 > SCREEN_HEIGHT - MARGIN * 1.5:  # If too low
            menu_y = SCREEN_HEIGHT - MARGIN * 1.5 - 170
            
        for button in self.upgrade_buttons.values():
            button.x = menu_x
            button.y = menu_y + (self.upgrade_buttons['range'].y)
            menu_y += button.height + 12
            
    def draw(self, screen):
        if self.game_state.is_game_started:
            # Draw game UI (including tower buttons)
            self.draw_game_ui(screen)
            
            # Draw pause button
            pygame.draw.rect(screen, MENU_COLORS['button'], self.pause_button)
            pause_icon_color = MENU_COLORS['button_text']
            if not self.game_state.is_paused:
                # Draw pause icon
                bar_width = 4
                pygame.draw.rect(screen, pause_icon_color, 
                               (self.pause_button.x + 12, self.pause_button.y + 10, 
                                bar_width, self.pause_button.height - 20))
                pygame.draw.rect(screen, pause_icon_color, 
                               (self.pause_button.x + 24, self.pause_button.y + 10, 
                                bar_width, self.pause_button.height - 20))
            else:
                # Draw play icon (triangle)
                points = [(self.pause_button.x + 15, self.pause_button.y + 10),
                         (self.pause_button.x + 15, self.pause_button.y + 30),
                         (self.pause_button.x + 30, self.pause_button.y + 20)]
                pygame.draw.polygon(screen, pause_icon_color, points)

            if self.game_state.is_paused:
                self.draw_pause_menu(screen)
        else:
            self.draw_start_screen(screen)
            
    def draw_icon(self, screen, icon_type, position):
        """Draw a UI icon based on the icon type"""
        icon_config = UI_ICONS[icon_type]
        size = icon_config['size']
        color = icon_config['color']
        
        # Transform points to screen position
        points = [(x + position[0], y + position[1]) for x, y in icon_config['points']]
        
        # Draw the icon
        pygame.draw.polygon(screen, color, points)
        # Add outline for better visibility
        pygame.draw.polygon(screen, (255, 255, 255), points, 2)

    def draw_fancy_panel(self, screen, rect, gradient=True):
        """Draw a fancy panel with medieval-themed gradient and decorative borders"""
        if gradient:
            # Create gradient background with stone texture
            surface = pygame.Surface((rect.width, rect.height))
            for i in range(rect.height):
                progress = i / rect.height
                color = [int(a + (b - a) * progress) for a, b in zip(STONE_GRADIENT[0], STONE_GRADIENT[1])]
                # Add subtle texture variation
                noise = (i % 4) - 2
                color = [max(0, min(255, c + noise)) for c in color]
                pygame.draw.line(surface, color, (0, i), (rect.width, i))
            screen.blit(surface, rect)
        else:
            pygame.draw.rect(screen, PANEL_BACKGROUND, rect)

        # Draw ornate border
        pygame.draw.rect(screen, PANEL_BORDER, rect, 2)
        
        # Draw highlight line at top for aged metal effect
        pygame.draw.line(screen, PANEL_HIGHLIGHT, 
                        (rect.left, rect.top + 1),
                        (rect.right, rect.top + 1), 1)
        
        # Draw corner decorations with medieval motifs
        corner_size = 6
        for x, y in [(rect.left, rect.top), (rect.right - corner_size, rect.top),
                     (rect.left, rect.bottom - corner_size), (rect.right - corner_size, rect.bottom - corner_size)]:
            # Draw corner background
            pygame.draw.rect(screen, CASTLE_STONE, (x, y, corner_size, corner_size))
            # Draw ornate border
            pygame.draw.rect(screen, AGED_BRONZE, (x, y, corner_size, corner_size), 1)
            # Add inner detail
            pygame.draw.line(screen, PANEL_HIGHLIGHT,
                           (x + 1, y + corner_size//2),
                           (x + corner_size - 1, y + corner_size//2), 1)

    def draw_wave_counter(self, screen):
        """Draw enhanced wave counter"""
        wave_text = f"WAVE {self.game_state.current_wave}"
        text_surface = self.large_font.render(wave_text, True, WAVE_TEXT_COLOR)
        text_rect = text_surface.get_rect()
        text_rect.centerx = SCREEN_WIDTH // 2
        text_rect.top = 10

        # Draw background panel
        panel_rect = text_rect.inflate(40, 20)
        self.draw_fancy_panel(screen, panel_rect, gradient=False)
        
        # Draw text with shadow
        shadow_surface = self.large_font.render(wave_text, True, (0, 0, 0))
        screen.blit(shadow_surface, (text_rect.x + 2, text_rect.y + 2))
        screen.blit(text_surface, text_rect)

    def draw_resource_panel(self, screen, rect, icon_type, value, color):
        """Draw a decorated medieval-style panel for a single resource"""
        # Draw panel with gradient background
        for y in range(rect.height):
            progress = y / rect.height
            base_color = [int(a + (b - a) * progress) for a, b in zip(STONE_GRADIENT[0], STONE_GRADIENT[1])]
            pygame.draw.line(screen, base_color,
                           (rect.x, rect.y + y),
                           (rect.right, rect.y + y))

        # Draw ornate border with aged bronze color
        pygame.draw.rect(screen, PANEL_BORDER, rect, 2)
        
        # Draw corner decorations with medieval motifs
        corner_size = 8
        for corner in [(rect.x, rect.y), (rect.right - corner_size, rect.y),
                      (rect.x, rect.bottom - corner_size), (rect.right - corner_size, rect.bottom - corner_size)]:
            # Draw corner background in darker stone
            pygame.draw.rect(screen, CASTLE_STONE, 
                           (*corner, corner_size, corner_size))
            # Draw corner border in aged bronze
            pygame.draw.rect(screen, AGED_BRONZE,
                           (*corner, corner_size, corner_size), 1)
            # Draw inner detail
            pygame.draw.line(screen, PANEL_HIGHLIGHT,
                           (corner[0] + 2, corner[1] + corner_size//2),
                           (corner[0] + corner_size - 2, corner[1] + corner_size//2), 1)

        # Calculate centered positions
        icon_x = rect.x + 32
        icon_y = rect.centery
        text_x = icon_x + 42

        # Draw icon with enhanced medieval effects
        if icon_type == 'gems':
            # Add magical glow effect for gems
            for radius in range(UI_ICON_SIZE-2, UI_ICON_SIZE+3, 2):
                pygame.draw.circle(screen, (*ROYAL_PURPLE, 25), 
                                (icon_x, icon_y), radius)
        
        self.draw_icon(screen, icon_type, (icon_x, icon_y))

        # Draw value with medieval style text effect
        large_font = pygame.font.Font(None, 36)
        # Draw multiple layers of shadow for parchment-like effect
        shadow_offsets = [(2, 2), (2, 1), (1, 2)]
        for offset_x, offset_y in shadow_offsets:
            shadow_surface = large_font.render(str(value), True, TEXT_SHADOW)
            screen.blit(shadow_surface, (text_x + offset_x, rect.centery - 10 + offset_y))
        
        # Draw main text with parchment color
        text_surface = large_font.render(str(value), True, TEXT_NORMAL if color == UI_TEXT else color)
        screen.blit(text_surface, (text_x, rect.centery - 10))

        # Draw decorative flourishes in corners
        accent_length = 8
        for corner in [(rect.x, rect.y), (rect.right, rect.y),
                      (rect.x, rect.bottom), (rect.right, rect.bottom)]:
            x, y = corner
            if x == rect.right:
                x -= accent_length
            if y == rect.bottom:
                y -= accent_length
            pygame.draw.line(screen, AGED_BRONZE,
                           (x, y), (x + accent_length, y), 1)
            pygame.draw.line(screen, AGED_BRONZE,
                           (x, y), (x, y + accent_length), 1)

    def draw_game_ui(self, screen):
        # Draw wave counter at top
        if self.game_state.is_game_started:
            self.draw_wave_counter(screen)
        
        # Draw bottom bar with elaborate medieval design
        bottom_bar_rect = pygame.Rect(0, SCREEN_HEIGHT - BOTTOM_BAR_HEIGHT, 
                                    SCREEN_WIDTH, BOTTOM_BAR_HEIGHT)
        
        # Draw textured background with deeper gradient
        for y in range(bottom_bar_rect.height):
            progress = y / bottom_bar_rect.height
            base_color = [int(a + (b - a) * progress) for a, b in zip((45, 45, 50), (60, 60, 65))]
            noise = (y % 4) - 2  # More pronounced texture
            color = (base_color[0] + noise, base_color[1] + noise, base_color[2] + noise)
            pygame.draw.line(screen, color,
                           (0, bottom_bar_rect.y + y),
                           (SCREEN_WIDTH, bottom_bar_rect.y + y))

        # Draw ornate top border
        border_height = 8
        for i in range(border_height):
            progress = i / border_height
            color = [int(a + (b - a) * progress) for a, b in zip((35, 35, 40), (70, 70, 75))]
            pygame.draw.line(screen, color,
                           (0, bottom_bar_rect.y + i),
                           (SCREEN_WIDTH, bottom_bar_rect.y + i))

        # Draw decorative patterns
        pattern_spacing = 160
        for x in range(0, SCREEN_WIDTH + pattern_spacing, pattern_spacing):
            # Draw gothic arch
            arch_height = 20
            arch_width = 40
            arch_y = bottom_bar_rect.y + border_height
            
            # Draw arch shadow
            shadow_points = [(x-1, arch_y+1),
                           (x + arch_width//2, arch_y - arch_height + 1),
                           (x + arch_width+1, arch_y+1)]
            pygame.draw.lines(screen, (40, 40, 45), False, shadow_points, 3)
            
            # Draw main arch
            arch_points = [(x, arch_y),
                          (x + arch_width//2, arch_y - arch_height),
                          (x + arch_width, arch_y)]
            pygame.draw.lines(screen, (75, 75, 80), False, arch_points, 2)
            
            # Add decorative circle at arch peak
            pygame.draw.circle(screen, (40, 40, 45), 
                             (x + arch_width//2, arch_y - arch_height), 4)
            pygame.draw.circle(screen, (75, 75, 80), 
                             (x + arch_width//2, arch_y - arch_height), 3)
            
            # Draw small vertical accent lines
            for i in range(3):
                line_x = x + (arch_width * i // 2)
                if line_x < SCREEN_WIDTH:
                    pygame.draw.line(screen, (70, 70, 75),
                                   (line_x, arch_y),
                                   (line_x, arch_y + 15), 2)
                    # Add small decorative diamond
                    diamond_y = arch_y + 18
                    diamond_points = [(line_x, diamond_y - 3),
                                    (line_x + 3, diamond_y),
                                    (line_x, diamond_y + 3),
                                    (line_x - 3, diamond_y)]
                    pygame.draw.polygon(screen, (70, 70, 75), diamond_points)

        # Draw horizontal decorative lines
        line_y = bottom_bar_rect.bottom - 25
        pygame.draw.line(screen, (70, 70, 75), (0, line_y), (SCREEN_WIDTH, line_y), 1)
        pygame.draw.line(screen, (45, 45, 50), (0, line_y + 1), (SCREEN_WIDTH, line_y + 1), 1)

        # Draw subtle corner flourishes
        flourish_size = 30
        corners = [(0, bottom_bar_rect.bottom),
                  (SCREEN_WIDTH, bottom_bar_rect.bottom)]
        for x, y in corners:
            for i in range(3):
                offset = i * 10
                pygame.draw.arc(screen, (70, 70, 75),
                              (x - flourish_size + offset, y - flourish_size,
                               flourish_size, flourish_size),
                              0, 3.14159/2, 2)

        # Calculate positions for resource panels
        panel_spacing = 25
        start_x = MARGIN + 10
        panel_y = SCREEN_HEIGHT - BOTTOM_BAR_HEIGHT + (BOTTOM_BAR_HEIGHT - RESOURCE_PANEL_HEIGHT) // 2
          # Draw resource panels with ornate connecting decorations
        # Gold panel
        gold_rect = pygame.Rect(start_x, panel_y, RESOURCE_PANEL_WIDTH, RESOURCE_PANEL_HEIGHT)
        
        # Draw ornate connector between panels
        connector_y = panel_y + RESOURCE_PANEL_HEIGHT//2
        connector_start = gold_rect.right + 5
        connector_end = gold_rect.right + panel_spacing - 5
        connector_mid = (connector_start + connector_end) // 2
        
        # Draw main connecting line with gradient
        for x in range(int(connector_start), int(connector_end)):
            progress = (x - connector_start) / (connector_end - connector_start)
            color_val = int(65 + 10 * abs(math.sin(progress * math.pi)))
            pygame.draw.line(screen, (color_val, color_val, color_val + 5),
                           (x, connector_y),
                           (x + 1, connector_y), 2)
        
        # Draw decorative nodes
        for x in [connector_start, connector_mid, connector_end]:
            pygame.draw.circle(screen, (45, 45, 50), (int(x), connector_y), 4)
            pygame.draw.circle(screen, (70, 70, 75), (int(x), connector_y), 3)
        
        self.draw_resource_panel(screen, gold_rect, 'gold', 
                               self.game_state.currency_manager.gold, GOLD_COLOR)

        # Gems panel with adjusted position
        gems_rect = pygame.Rect(start_x + RESOURCE_PANEL_WIDTH + panel_spacing, 
                              panel_y, RESOURCE_PANEL_WIDTH, RESOURCE_PANEL_HEIGHT)
        self.draw_resource_panel(screen, gems_rect, 'gems',
                               self.game_state.currency_manager.gems, GEM_COLOR)

        # Right side panels
        right_panel_x = SCREEN_WIDTH - RESOURCE_PANEL_WIDTH - MARGIN

        # Tower count panel (moved to right)
        tower_count = f"{len(self.game_state.tower_manager.towers)}/{MAX_TOWERS}"
        tower_color = (255, 0, 0) if len(self.game_state.tower_manager.towers) >= MAX_TOWERS else UI_TEXT
        towers_rect = pygame.Rect(right_panel_x - RESOURCE_PANEL_WIDTH - panel_spacing,
                                panel_y, RESOURCE_PANEL_WIDTH, RESOURCE_PANEL_HEIGHT)
        self.draw_resource_panel(screen, towers_rect, 'towers', tower_count, tower_color)

        # Base health panel (rightmost)
        health_rect = pygame.Rect(right_panel_x, panel_y, 
                                RESOURCE_PANEL_WIDTH, RESOURCE_PANEL_HEIGHT)
        self.draw_base_health_panel(screen, health_rect)        # Draw tower buttons
        self.draw_tower_buttons(screen)

        # Draw upgrade menu if visible
        if self.tower_menu_visible and self.selected_tower:
            self.draw_upgrade_menu(screen)
        
        # Draw tower preview last (on top)
        self.draw_tower_preview(screen)

    def draw_base_health_panel(self, screen, rect):
        """Draw a specialized panel for base health with a health bar"""
        # Draw panel background with gradient
        self.draw_fancy_panel(screen, rect)
        
        # Draw health icon with optimized spacing
        health_icon_x = rect.x + 30
        health_icon_y = rect.centery
        self.draw_icon(screen, 'base_health', (health_icon_x, health_icon_y))        # Draw health bar with improved visuals
        bar_width = rect.width - 95  # Even more compact to prevent overflow
        bar_height = 10  # Slightly shorter for elegance
        health_percent = self.game_state.base_health / BASE_MAX_HEALTH
        bar_x = health_icon_x + 42  # Perfect alignment
        bar_y = rect.centery - bar_height//2
        
        # Draw background (empty health) with darker color
        pygame.draw.rect(screen, (45, 45, 50), 
                        (bar_x, bar_y, bar_width, bar_height))
        
        # Draw filled health with smoother gradient
        health_width = int(bar_width * health_percent)
        if health_percent > 0.6:  # Full health range
            color1, color2 = (40, 180, 40), (80, 255, 80)
        elif health_percent > 0.3:  # Medium health range
            color1, color2 = (180, 180, 40), (255, 255, 80)
        else:  # Low health range
            color1, color2 = (180, 40, 40), (255, 80, 80)
        
        for i in range(health_width):
            progress = i / bar_width
            color = [int(a + (b - a) * progress) for a, b in zip(color1, color2)]
            pygame.draw.line(screen, color, 
                           (bar_x + i, bar_y),
                           (bar_x + i, bar_y + bar_height))

    def draw_tower_buttons(self, screen):
        for tower_type, button in self.buttons.items():
            if tower_type.startswith('tower_'):
                # Draw button background with stone gradient
                button_surface = pygame.Surface((button.width, button.height))
                for i in range(button.height):
                    progress = i / button.height
                    color = [int(a + (b - a) * progress) for a, b in zip(STONE_GRADIENT[0], STONE_GRADIENT[1])]
                    pygame.draw.line(button_surface, color, (0, i), (button.width, i))
                screen.blit(button_surface, button)
                
                # Draw ornate border with aged bronze
                pygame.draw.rect(screen, PANEL_BORDER, button, 2)
                pygame.draw.line(screen, PANEL_HIGHLIGHT,
                               (button.left, button.top + 1),
                               (button.right, button.top + 1), 1)
                
                # Draw medieval tower icon
                self.draw_tower_icon(screen, tower_type, button.center)
                
                # Add decorative corners with bronze accents
                corner_size = 6
                for corner in [(button.left, button.top),
                             (button.right - corner_size, button.top),
                             (button.left, button.bottom - corner_size),
                             (button.right - corner_size, button.bottom - corner_size)]:
                    pygame.draw.rect(screen, AGED_BRONZE,
                                   (*corner, corner_size, corner_size), 1)
                
                # Draw cost with parchment-style text effect
                cost = TOWER_TYPES[tower_type.split('_')[1]]['cost']
                cost_text = str(cost)
                
                # Draw text shadow for depth
                shadow_pos = (button.centerx - self.font.size(cost_text)[0]//2 + 1,
                            button.bottom + 6)
                self.draw_text(screen, cost_text, shadow_pos, TEXT_SHADOW)
                
                # Draw main text in gold
                cost_pos = (button.centerx - self.font.size(cost_text)[0]//2,
                           button.bottom + 5)
                self.draw_text(screen, cost_text, cost_pos, GOLD_ACCENT)
    
    def draw_start_screen(self, screen):
        # Draw start game button with bigger size
        button = self.buttons['start_game']
        pygame.draw.rect(screen, UI_BACKGROUND, button)
        pygame.draw.rect(screen, (100, 100, 100), button, 3)  # Thicker border
        
        text = "Start Game"
        text_surface = self.large_font.render(text, True, UI_TEXT)
        text_pos = (button.centerx - text_surface.get_width()//2,
                   button.centery - text_surface.get_height()//2)
        screen.blit(text_surface, text_pos)

    def draw_upgrade_menu(self, screen):
        if not self.selected_tower:
            return
            
        # Define menu dimensions
        menu_padding = 12
        menu_width = 200  # Wider menu
        button_height = 35  # Taller buttons
        stats_spacing = 20  # Space between stats
        
        # Calculate heights
        stats_height = 120  # More space for stats
        buttons_height = (len(self.upgrade_buttons) * (button_height + menu_padding))
        total_height = stats_height + buttons_height + menu_padding * 2
        
        # Position menu
        tower_pos = self.selected_tower.position
        menu_x = min(max(tower_pos[0] - menu_width//2, menu_padding), 
                    SCREEN_WIDTH - menu_width - menu_padding)
        menu_y = max(menu_padding, tower_pos[1] - total_height - menu_padding)
        
        # Create menu rectangle
        menu_rect = pygame.Rect(menu_x, menu_y, menu_width, total_height)
        
        # Draw menu background with gradient
        s = pygame.Surface((menu_width, total_height))
        s.fill((30, 30, 35))  # Slightly blue-tinted dark background
        s.set_alpha(245)  # More solid background
        screen.blit(s, (menu_x, menu_y))
        
        # Draw border with gradient
        pygame.draw.rect(screen, (80, 80, 100), menu_rect, 2)  # Main border
        pygame.draw.line(screen, (100, 100, 120), 
                        (menu_rect.left, menu_rect.top),
                        (menu_rect.right, menu_rect.top), 2)  # Top highlight
        
        # Draw stats with improved layout
        stats_y = menu_y + menu_padding
        stats = [
            ("Level", f"{self.selected_tower.level}"),
            ("Range", f"{int(self.selected_tower.range)}"),
            ("Damage", f"{int(self.selected_tower.damage)}"),
            ("Speed", f"{self.selected_tower.attack_speed:.1f}"),
            ("Target", f"{self.selected_tower.target_mode.title()}")
        ]
        
        for label, value in stats:
            # Draw label on left
            label_surface = self.font.render(label + ":", True, (160, 160, 180))
            screen.blit(label_surface, (menu_x + menu_padding, stats_y))
            
            # Draw value on right
            value_surface = self.font.render(value, True, (220, 220, 240))
            value_x = menu_x + menu_width - menu_padding - value_surface.get_width()
            screen.blit(value_surface, (value_x, stats_y))
            
            stats_y += stats_spacing

        # Draw target mode button
        button_width = menu_width - menu_padding * 2
        target_button = pygame.Rect(menu_x + menu_padding, stats_y + menu_padding,
                                  button_width, button_height)
        
        # Draw target button with gradient effect
        pygame.draw.rect(screen, (50, 50, 80), target_button)  # Base color
        pygame.draw.rect(screen, (70, 70, 100), target_button, 2)  # Border
        
        # Add button highlight
        highlight = pygame.Surface((button_width, 8), pygame.SRCALPHA)
        highlight.fill((255, 255, 255, 15))
        screen.blit(highlight, (target_button.x, target_button.y))
        
        # Center the target mode text
        text = "Change Target Mode"
        text_surface = self.font.render(text, True, (220, 220, 240))
        text_x = target_button.centerx - text_surface.get_width() // 2
        text_y = target_button.centery - text_surface.get_height() // 2
        screen.blit(text_surface, (text_x, text_y))
        
        # Store the button for click detection
        self.target_mode_button = target_button
        
        # Draw upgrade buttons
        button_y = stats_y + button_height + menu_padding * 2
        for attribute, button in self.upgrade_buttons.items():
            # Update button position and size
            button.x = menu_x + menu_padding
            button.y = button_y
            button.width = button_width
            button.height = button_height
            button_y += button_height + menu_padding // 2
            
            # Draw button with gradient
            if attribute == 'sell':
                base_color = (100, 50, 50)  # Red for sell button
                text = f"Sell ({self.selected_tower.get_sell_value()})"
            else:
                base_color = (50, 50, 80)  # Blue for upgrade buttons
                cost = self.selected_tower.get_upgrade_cost(attribute)
                text = f"{attribute.replace('_', ' ').title()} ({cost})"            # Draw button background with gradient
            pygame.draw.rect(screen, base_color, button)
            # Calculate brighter color for border by adding 20 to each RGB component
            border_color = tuple(min(c + 20, 255) for c in base_color)
            pygame.draw.rect(screen, border_color, button, 2)
            
            # Add highlight effect
            highlight = pygame.Surface((button_width, 8), pygame.SRCALPHA)
            highlight.fill((255, 255, 255, 15))
            screen.blit(highlight, (button.x, button.y))
            
            # Center the text
            text_surface = self.font.render(text, True, (220, 220, 240))
            text_x = button.centerx - text_surface.get_width() // 2
            text_y = button.centery - text_surface.get_height() // 2
            screen.blit(text_surface, (text_x, text_y))
    
    def draw_text(self, screen, text, position, color):
        """Utility function to draw text"""
        text_surface = self.font.render(text, True, color)
        screen.blit(text_surface, position)

    def update(self, dt=0):
        """Update UI state"""
        # Handle slider dragging
        if self.slider_dragging and pygame.mouse.get_pressed()[0]:
            mouse_x = pygame.mouse.get_pos()[0]
            element = self.settings_elements[self.slider_dragging]
            rect = element['rect']
            
            # Calculate new value based on mouse position
            # Ensure we have some padding to make min/max values easier to hit
            padding = 5
            normalized_x = max(0, min(rect.width, mouse_x - rect.x))
            value = normalized_x / rect.width
            
            # Clamp value between 0 and 1 with extra precision
            value = max(0.0, min(1.0, round(value, 2)))
            
            # Update value and settings only if changed
            if abs(element['value'] - value) >= 0.01:  # Small threshold to prevent unnecessary updates
                element['value'] = value
                self.game_state.update_setting(self.slider_dragging, value)
                
        elif not pygame.mouse.get_pressed()[0]:
            self.slider_dragging = None

    def show_game_complete_menu(self):
        """Show the game complete menu"""
        self.game_state.is_game_started = False  # Stop the game
        # Reset UI state
        self.selected_tower = None
        self.tower_menu_visible = False
        # Game complete menu will be drawn in draw_start_screen
        
    def draw_tower_preview(self, screen):
        if not self.tower_preview:
            return
            
        # Get mouse position and check validity
        mouse_pos = pygame.mouse.get_pos()
        valid_placement = self.is_valid_placement_area(mouse_pos) and not self.game_state.tower_manager.is_position_occupied(mouse_pos)
        
        # Draw tower preview with more distinct visual feedback
        preview_alpha = 180 if valid_placement else 120
        preview_color = (100, 255, 100, preview_alpha) if valid_placement else (255, 100, 100, preview_alpha)
        preview_surface = pygame.Surface((40, 40), pygame.SRCALPHA)
        pygame.draw.circle(preview_surface, preview_color, (20, 20), 20)
        
        # Add a pulsing effect for invalid placements
        if not valid_placement:
            pulse = abs(math.sin(pygame.time.get_ticks() * 0.005)) * 0.3 + 0.7
            preview_surface.set_alpha(int(preview_alpha * pulse))
        
        screen.blit(preview_surface, (mouse_pos[0] - 20, mouse_pos[1] - 20))
        
        # Draw range circle
        range_surface = pygame.Surface(
            (self.tower_preview['range'] * 2, self.tower_preview['range'] * 2), 
            pygame.SRCALPHA
        )
        range_color = (100, 255, 100, 40) if valid_placement else (255, 100, 100, 40)
        pygame.draw.circle(
            range_surface, 
            range_color,
            (self.tower_preview['range'], self.tower_preview['range']),
            self.tower_preview['range']
        )
        screen.blit(
            range_surface,
            (mouse_pos[0] - self.tower_preview['range'],
             mouse_pos[1] - self.tower_preview['range'])
        )
        
        # Add visual hint for invalid placement
        if not valid_placement:
            x = mouse_pos[0]
            y = mouse_pos[1]
            size = 10
            color = (255, 100, 100)
            pygame.draw.line(screen, color, (x - size, y - size), (x + size, y + size), 2)
            pygame.draw.line(screen, color, (x - size, y + size), (x + size, y - size), 2)

    def handle_event(self, event):
        """Handle UI events"""
        if event.type == pygame.MOUSEBUTTONDOWN:
            pos = event.pos
            button = event.button
            
            # Handle start button first if game not started
            if not self.game_state.is_game_started:
                log_debug(f"UIMANAGER: Game not started, checking start button at {self.buttons['start_game']}")
                if self.buttons['start_game'].collidepoint(pos):
                    log_debug("UIMANAGER: Start button clicked, starting game")
                    self.game_state.start_game()
                    return True
                    
            # If game started, handle pause/settings first
            if self.pause_button.collidepoint(pos):
                self.game_state.toggle_pause()
                return True
                
            if self.game_state.is_paused:
                if self.game_state.show_settings:
                    self.handle_settings_click(pos)
                else:
                    self.handle_pause_menu_click(pos)
                return True
            
            # Handle normal gameplay clicks
            if button == 3:  # Right click
                # Clear all selection and preview states
                self.selected_tower = None
                self.tower_menu_visible = False
                self.tower_preview = None
                if hasattr(self, 'selected_tower_type'):
                    delattr(self, 'selected_tower_type')
                return True
            else:  # Left click
                if self.tower_menu_visible:
                    self.handle_tower_menu_click(pos)
                else:
                    self.handle_game_click(pos)
            return True
            
        return False

    def handle_pause_menu_click(self, pos):
        """Handle clicks in the pause menu with improved edge case handling"""
        # Early return if game is not actually paused
        if not self.game_state.is_paused:
            return
            
        # Check if click is within menu bounds
        for button_name, button_rect in self.pause_menu_buttons.items():
            if button_rect.collidepoint(pos):
                if button_name == 'resume':
                    self.game_state.toggle_pause()
                elif button_name == 'settings':
                    self.game_state.toggle_settings()
                elif button_name == 'quit':
                    # Add confirmation for quit
                    if self.confirm_quit():
                        pygame.quit()
                        sys.exit()
                break  # Exit after handling button click
                
    def confirm_quit(self):
        """Show a simple confirmation dialog for quitting"""
        return True  # TODO: Implement proper confirmation dialog

    def handle_settings_click(self, pos):
        """Handle clicks in the settings menu with improved edge case handling"""
        # Early return if settings aren't actually shown
        if not self.game_state.show_settings:
            return

        # Handle back button
        if self.settings_back.collidepoint(pos):
            self.game_state.toggle_settings()
            return

        # Handle settings elements
        for setting_name, element in self.settings_elements.items():
            if element['rect'].collidepoint(pos):
                if element['type'] == 'checkbox':
                    # Toggle checkbox value
                    element['value'] = not element['value']
                    self.game_state.update_setting(setting_name, element['value'])
                    # Play feedback sound if available
                    # TODO: Add sound feedback
                elif element['type'] == 'slider':
                    # Start dragging the slider
                    if not self.slider_dragging:
                        self.slider_dragging = setting_name
                return

        # Click outside any interactive elements - could add a "click to close" behavior here
        if pos[1] < SCREEN_HEIGHT / 4:  # If clicked in top quarter of screen
            self.game_state.toggle_settings()  # Close settings

    def draw_pause_menu(self, screen):
        # Draw semi-transparent overlay
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill(MENU_COLORS['background'])
        screen.blit(overlay, (0, 0))

        if self.game_state.show_settings:
            self.draw_settings_menu(screen)
        else:
            # Draw pause menu buttons
            for button_name, button_rect in self.pause_menu_buttons.items():
                pygame.draw.rect(screen, MENU_COLORS['button'], button_rect)
                text = button_name.title()
                text_surface = self.font.render(text, True, MENU_COLORS['button_text'])
                text_rect = text_surface.get_rect(center=button_rect.center)
                screen.blit(text_surface, text_rect)

    def draw_settings_menu(self, screen):
        # Draw settings title with more space at top
        title = self.large_font.render("Settings", True, MENU_COLORS['button_text'])
        screen.blit(title, (SCREEN_WIDTH//2 - title.get_width()//2, SCREEN_HEIGHT//4 - 80))

        # Draw settings elements
        for setting_name, element in self.settings_elements.items():
            rect = element['rect']
            
            # Draw setting label with larger offset
            label = setting_name.replace('_', ' ').title()
            text_surface = self.font.render(label, True, MENU_COLORS['button_text'])
            screen.blit(text_surface, (rect.x, rect.y - 30))

            if element['type'] == 'slider':
                # Draw slider bar with improved visuals
                pygame.draw.rect(screen, MENU_COLORS['slider_bar'], rect)
                # Draw slider handle
                handle_x = rect.x + (rect.width * element['value'])
                handle_rect = pygame.Rect(handle_x - 12, rect.y, 24, rect.height)
                pygame.draw.rect(screen, MENU_COLORS['slider_handle'], handle_rect)
                
                # Draw value percentage with offset
                value_text = f"{int(element['value'] * 100)}%"
                value_surface = self.font.render(value_text, True, MENU_COLORS['button_text'])
                screen.blit(value_surface, (rect.right + 20, rect.y + rect.height//4))
            else:
                # Draw checkbox container
                pygame.draw.rect(screen, MENU_COLORS['button'], rect)
                if element['value']:
                    # Draw checkmark with more padding
                    checkbox_inner = rect.inflate(-rect.height * 0.4, -rect.height * 0.4)
                    pygame.draw.rect(screen, MENU_COLORS['checkbox_checked'], checkbox_inner)

        # Draw back button
        pygame.draw.rect(screen, MENU_COLORS['button'], self.settings_back)
        back_text = self.font.render("Back", True, MENU_COLORS['button_text'])
        back_rect = back_text.get_rect(center=self.settings_back.center)
        screen.blit(back_text, back_rect)
        
    def show_game_over_menu(self):
        self.game_state.is_paused = True
        self.game_over = True
        
    def draw_tower_icon(self, screen, tower_type, position, size=40):
        """Draw a tower icon at the given position with the given size"""
        # Determine tower subtype (archer, warrior, mage)
        tower_name = tower_type.split('_')[1] if isinstance(tower_type, str) else tower_type
        
        if tower_name == 'archer':
            # Draw bow
            pygame.draw.arc(screen, ARCHER_COLORS['accent'], 
                          (position[0] - size//4, position[1] - size//4, size//2, size//2),
                          -0.5, 0.5, 2)
            # Draw arrow
            pygame.draw.line(screen, IRON,
                           (position[0], position[1] - size//8),
                           (position[0], position[1] - size//3), 2)
            
        elif tower_name == 'warrior':
            # Draw crossed swords
            for angle in [-0.4, 0.4]:
                # Blade
                sword_start = (position[0], position[1] - size//8)
                sword_end = (position[0] + math.cos(angle) * size//3,
                           position[1] - size//8 - math.sin(angle) * size//3)
                pygame.draw.line(screen, WARRIOR_COLORS['accent'],
                               sword_start, sword_end, 3)
                # Handle
                handle_end = (sword_end[0] + math.cos(angle) * size//8,
                            sword_end[1] - math.sin(angle) * size//8)
                pygame.draw.line(screen, LEATHER,
                               sword_end, handle_end, 3)
                
        else:  # mage
            # Draw staff
            pygame.draw.line(screen, DARK_WOOD,
                           (position[0], position[1] - size//2),
                           (position[0], position[1] + size//4), 2)
            # Draw orb
            pygame.draw.circle(screen, MAGE_COLORS['accent'],
                            (position[0], position[1] - size//2), size//6)
            # Draw sparkles
            sparkle_positions = [
                (size//5, -size//3), (-size//5, -size//3), (0, -size//2),
                (size//7, -size//4), (-size//7, -size//4)
            ]
            for offset in sparkle_positions:
                x = position[0] + offset[0]
                y = position[1] + offset[1]
                pygame.draw.circle(screen, (*ROYAL_PURPLE, 50), (x, y), 3)
                pygame.draw.circle(screen, MAGE_COLORS['highlight'], (x, y), 1)

        # Add a base shadow effect
        shadow_points = [
            (position[0] - size//2, position[1] + size//4),
            (position[0], position[1] + size//3),
            (position[0] + size//2, position[1] + size//4)
        ]
        pygame.draw.polygon(screen, PANEL_BACKGROUND, shadow_points)
        
    def draw_medieval_tower_icon(self, screen, tower_type, center_pos):
        """Draw detailed medieval-style tower icons"""
        if 'archer' in tower_type:
            # Draw archer tower (castle tower with bow)
            # Base tower with stone texture
            castle_points = [
                (center_pos[0] - 15, center_pos[1] + 10),  # Bottom left
                (center_pos[0] + 15, center_pos[1] + 10),  # Bottom right
                (center_pos[0] + 15, center_pos[1] - 15),  # Top right
                (center_pos[0] - 15, center_pos[1] - 15),  # Top left
            ]
            pygame.draw.polygon(screen, ARCHER_COLORS['base'], castle_points)
            pygame.draw.polygon(screen, CASTLE_STONE, castle_points, 2)  # Stone outline
            
            # Crenellations with aged stone effect
            for x in range(-10, 12, 10):
                pygame.draw.rect(screen, ARCHER_COLORS['base'],
                               (center_pos[0] + x - 2, center_pos[1] - 18, 4, 6))
            
            # Bow and arrow with worn wood effect
            pygame.draw.arc(screen, ARCHER_COLORS['accent'],  # Dark wood bow
                          (center_pos[0] - 8, center_pos[1] - 12, 16, 16),
                          -0.5, 0.5, 2)
            # Arrow shaft with iron finish
            pygame.draw.line(screen, IRON,
                           (center_pos[0], center_pos[1] - 4),
                           (center_pos[0], center_pos[1] - 12), 2)
            
        elif 'warrior' in tower_type:
            # Draw warrior tower (fortified tower with crossed swords)
            # Base tower with weathered stone
            castle_points = [
                (center_pos[0] - 15, center_pos[1] + 10),
                (center_pos[0] + 15, center_pos[1] + 10),
                (center_pos[0] + 12, center_pos[1] - 15),
                (center_pos[0] - 12, center_pos[1] - 15),
            ]
            pygame.draw.polygon(screen, WARRIOR_COLORS['base'], castle_points)
            pygame.draw.polygon(screen, CASTLE_STONE, castle_points, 2)
            
            # Draw crossed swords with metallic effect
            for angle in [-0.4, 0.4]:
                # Blade with iron coloring
                sword_start = (center_pos[0], center_pos[1] - 5)
                sword_end = (center_pos[0] + math.cos(angle) * 15,
                           center_pos[1] - 5 - math.sin(angle) * 15)
                pygame.draw.line(screen, WARRIOR_COLORS['accent'],
                               sword_start, sword_end, 3)
                # Handle with leather grip
                handle_end = (sword_end[0] + math.cos(angle) * 5,
                            sword_end[1] - math.sin(angle) * 5)
                pygame.draw.line(screen, LEATHER,
                               sword_end,
                               handle_end, 5)
            
        else:  # mage tower
            # Draw mage tower (tall tower with magical effects)
            # Base tower with mystical stone texture
            castle_points = [
                (center_pos[0] - 15, center_pos[1] + 10),
                (center_pos[0] + 15, center_pos[1] + 10),
                (center_pos[0] + 10, center_pos[1] - 18),
                (center_pos[0] - 10, center_pos[1] - 18),
            ]
            pygame.draw.polygon(screen, MAGE_COLORS['base'], castle_points)
            pygame.draw.polygon(screen, CASTLE_STONE, castle_points, 2)
            
            # Wizard hat with royal purple
            hat_points = [
                (center_pos[0], center_pos[1] - 25),
                (center_pos[0] - 12, center_pos[1] - 18),
                (center_pos[0] + 12, center_pos[1] - 18),
            ]
            pygame.draw.polygon(screen, MAGE_COLORS['accent'], hat_points)
            
            # Magic sparkles with mystical glow
            sparkle_positions = [
                (8, -15), (-8, -15), (0, -20),
                (6, -10), (-6, -10), (0, -12)
            ]
            for offset in sparkle_positions:
                x = center_pos[0] + offset[0]
                y = center_pos[1] + offset[1]
                # Mystical glow
                pygame.draw.circle(screen, (*ROYAL_PURPLE, 50),
                                (x, y), 4)
                # Bright sparkle
                pygame.draw.circle(screen, MAGE_COLORS['highlight'],
                                (x, y), 2)
        
        # Add tower base shadow for all types
        shadow_points = [
            (center_pos[0] - 18, center_pos[1] + 10),
            (center_pos[0], center_pos[1] + 13),
            (center_pos[0] + 18, center_pos[1] + 10)
        ]
        pygame.draw.polygon(screen, PANEL_BACKGROUND, shadow_points)

import logging
import os

def setup_debug_logging():
    # Create logs directory if it doesn't exist
    if not os.path.exists('logs'):
        os.makedirs('logs')

    # Set up logging configuration
    logging.basicConfig(
        filename='logs/debug.log',
        level=logging.DEBUG,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )

def log_debug(message):
    logging.debug(message)

def log_info(message):
    logging.info(message)

def log_error(message):
    logging.error(message)

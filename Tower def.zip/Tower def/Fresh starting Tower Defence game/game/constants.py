import pygame

# Screen settings
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720
FPS = 60
MARGIN = 60  # Margin from screen edges

# Base settings
BASE_MAX_HEALTH = 25
BASE_SIZE = 80  # Castle width
PATH_COLLISION_MARGIN = 50  # Minimum distance from path to place towers

# Path points for winding path
PATH_POINTS = [
    (0, SCREEN_HEIGHT // 3),  # Start from left side
    (SCREEN_WIDTH // 4, SCREEN_HEIGHT // 3),  # First horizontal
    (SCREEN_WIDTH // 4, SCREEN_HEIGHT // 4),  # Up
    (3 * SCREEN_WIDTH // 4, SCREEN_HEIGHT // 4),  # Second horizontal
    (3 * SCREEN_WIDTH // 4, 3 * SCREEN_HEIGHT // 4),  # Down
    (SCREEN_WIDTH // 2, 3 * SCREEN_HEIGHT // 4),  # Third horizontal
    (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2),  # Up slightly
    (SCREEN_WIDTH - BASE_SIZE, SCREEN_HEIGHT // 2)  # End at right side
]
PATH_START = PATH_POINTS[0]  # First point
PATH_END = PATH_POINTS[-1]  # Last point

# Colors
BACKGROUND_COLOR = (34, 139, 34)  # Dark green grass color
UI_BACKGROUND = (41, 41, 41)
UI_TEXT = (255, 255, 255)
WAVE_TEXT_COLOR = (255, 255, 255)  # White text for wave counter
GOLD_COLOR = (255, 215, 0)
GEM_COLOR = (0, 191, 255)
PATH_COLOR = (139, 69, 19)  # Brown dirt path
DECORATION_COLORS = {
    'tree': (0, 100, 0),  # Dark green
    'rock': (128, 128, 128)  # Gray
}

# Game settings
MAX_TOWERS = 10
TOWER_SELL_RATIO = 0.35
WAVE_INTERVAL = 3  # seconds

# Path settings
PATH_COLOR = (139, 69, 19)  # Brown dirt path
PATH_WIDTH = 40

# Tower types and upgrades
TOWER_TYPES = {
    'archer': {
        'cost': 100,
        'range': 150,
        'damage': 20,
        'attack_speed': 1.0,
        'projectile_speed': 300,
        'damage_type': 'ranged',
        'upgrade_paths': {
            'rapid': {
                'name': 'Rapid-Fire Archer',
                'description': 'High attack speed, shorter range',
                'stats': {
                    'attack_speed': 2.0,
                    'range': 120,
                    'damage': 15
                }
            },
            'sniper': {
                'name': 'Armor-Piercing Archer',
                'description': 'High damage, ignores armor',
                'stats': {
                    'attack_speed': 0.7,
                    'range': 200,
                    'damage': 45,
                    'armor_pierce': True
                }
            },
            'multi': {
                'name': 'Multishot Archer',
                'description': 'Hits multiple targets',
                'stats': {
                    'attack_speed': 0.8,
                    'range': 150,
                    'damage': 15,
                    'multi_shot': 3
                }
            }
        }
    },
    'warrior': {
        'cost': 150,
        'range': 60,
        'damage': 40,
        'attack_speed': 0.8,
        'damage_type': 'melee',
        'upgrade_paths': {
            'berserker': {
                'name': 'Berserker',
                'description': 'Very high attack speed, builds rage',
                'stats': {
                    'attack_speed': 2.0,
                    'range': 70,
                    'damage': 30,
                    'rage_bonus': True
                }
            },
            'knight': {
                'name': 'Heavy Knight',
                'description': 'High damage, can stun enemies',
                'stats': {
                    'attack_speed': 0.6,
                    'range': 60,
                    'damage': 80,
                    'stun_chance': 0.3
                }
            },
            'samurai': {
                'name': 'Samurai',
                'description': 'Deals bleeding damage over time',
                'stats': {
                    'attack_speed': 1.0,
                    'range': 65,
                    'damage': 35,
                    'bleed_damage': 20
                }
            }
        }
    },
    'mage': {
        'cost': 200,
        'range': 120,
        'damage': 30,
        'attack_speed': 1.2,
        'projectile_speed': 250,
        'damage_type': 'magic',
        'upgrade_paths': {
            'elementalist': {
                'name': 'Elementalist',
                'description': 'Cycles between fire, ice, and lightning',
                'stats': {
                    'attack_speed': 1.0,
                    'range': 130,
                    'damage': 40,
                    'elemental_cycle': True
                }
            },
            'archmage': {
                'name': 'Archmage',
                'description': 'Powerful single target damage',
                'stats': {
                    'attack_speed': 0.8,
                    'range': 150,
                    'damage': 100,
                    'mana_burn': True
                }
            },
            'necromancer': {
                'name': 'Necromancer',
                'description': 'Summons skeletons from fallen enemies',
                'stats': {
                    'attack_speed': 1.0,
                    'range': 100,
                    'damage': 25,
                    'raise_dead': True
                }
            }
        }
    }
}

# Effect types and their properties
STATUS_EFFECTS = {
    'burning': {
        'damage_per_second': 10,
        'duration': 3.0,
        'color': (255, 100, 0),  # Orange-red
        'stackable': True,
        'max_stacks': 3
    },
    'frozen': {
        'speed_multiplier': 0.5,
        'duration': 2.0,
        'color': (100, 200, 255),  # Light blue
        'stackable': False
    },
    'stunned': {
        'speed_multiplier': 0,
        'duration': 1.0,
        'color': (255, 255, 0),  # Yellow
        'stackable': False
    },
    'bleeding': {
        'damage_per_second': 15,
        'duration': 3.0,
        'color': (200, 0, 0),  # Deep red
        'stackable': True,
        'max_stacks': 2
    },
    'mana_burn': {
        'extra_magic_damage': 20,
        'duration': 2.0,
        'color': (180, 0, 255),  # Purple
        'stackable': False
    }
}

# Enemy types
ENEMY_TYPES = {    'normal': {
        'health': 40,
        'speed': 100,  # Moderate speed
        'gold_value': 10,
        'color': (200, 50, 50),  # Deep red
        'size': 12,  # Smaller size
        'resistances': {'melee': 1.0, 'ranged': 1.0, 'magic': 1.0}
    },
    'armored': {
        'health': 80,
        'speed': 80,  # Slower speed
        'gold_value': 20,
        'color': (70, 70, 80),  # Steel gray
        'size': 14,  # Slightly larger
        'resistances': {'melee': 0.5, 'ranged': 0.8, 'magic': 1.2}
    },
    'fast': {
        'health': 25,
        'speed': 200,  # Fast speed
        'gold_value': 15,
        'color': (255, 165, 0),  # Orange
        'size': 10,  # Smallest size
        'resistances': {'melee': 1.2, 'ranged': 0.8, 'magic': 1.0}
    }
}

# Boss settings
BOSS_STATS_MULTIPLIER = 5  # Base multiplier for boss stats
MEGA_BOSS_MULTIPLIER = 10  # Multiplier for wave 100 boss

# Settings defaults
DEFAULT_SETTINGS = {
    'volume': 0.5,  # 0.0 to 1.0
    'show_health_bars': True,
    'show_damage_numbers': True,
    'show_tower_ranges': False,
    'background_animations': True
}

# UI Colors for menus
MENU_COLORS = {
    'background': (0, 0, 0, 180),  # Semi-transparent black
    'button': (70, 70, 70),
    'button_hover': (90, 90, 90),
    'button_text': (255, 255, 255),
    'slider_bar': (100, 100, 100),
    'slider_handle': (200, 200, 200),
    'checkbox': (100, 100, 100),
    'checkbox_checked': (0, 255, 0)
}

# UI Settings
BOTTOM_BAR_HEIGHT = 100
UI_ICON_SIZE = 28

# Resource panel settings
RESOURCE_PANEL_WIDTH = 180  # Wider panels for better spacing
RESOURCE_PANEL_HEIGHT = 70  # Taller panels for better visibility
BOTTOM_BAR_HEIGHT = 100  # Slightly taller bottom bar

# UI icon configurations
UI_ICONS = {
    'gold': {
        'size': UI_ICON_SIZE,
        'color': GOLD_COLOR,
        'points': [  # Medieval coin with crown design
            (0, -12), (8, -10), (12, -4), 
            (12, 0), (12, 4), (8, 10),
            (0, 12), (-8, 10), (-12, 4),
            (-12, 0), (-12, -4), (-8, -10)
        ],
        'crown_points': [  # Crown detail on coin
            (-6, -6), (-4, -8), (-2, -6),
            (0, -8), (2, -6), (4, -8),
            (6, -6)
        ]
    },
    'gems': {
        'size': UI_ICON_SIZE,
        'color': GEM_COLOR,
        'points': [  # Faceted gem shape
            (0, -15), (8, -8), (12, 0),
            (8, 8), (0, 15), (-8, 8),
            (-12, 0), (-8, -8)
        ],
        'facet_lines': [  # Internal facet details
            [(-8, -8), (8, 8)],
            [(8, -8), (-8, 8)],
            [(0, -15), (0, 15)]
        ]
    },
    'towers': {
        'size': UI_ICON_SIZE,
        'color': UI_TEXT,
        'points': [  # Medieval tower with crenellations
            (-12, 15),  # Base
            (-12, -6),  # Main tower walls
            (-14, -6),  # Left merlon
            (-14, -9),
            (-10, -9),  # Left crenel
            (-10, -6),
            (-2, -6),
            (-2, -12),  # Center turret
            (2, -12),
            (2, -6),
            (10, -6),
            (10, -9),   # Right crenel
            (14, -9),
            (14, -6),   # Right merlon
            (12, -6),
            (12, 15)    # Base
        ]
    },
    'base_health': {
        'size': UI_ICON_SIZE,
        'color': (220, 50, 50),  # Red
        'points': [  # Fortified castle shape
            (-15, 15),  # Base left
            (-15, -3),  # Wall left
            (-13, -3),  # Left tower
            (-13, -9),  # Left battlements
            (-15, -9),
            (-15, -12),
            (-11, -12),
            (-11, -9),
            (-7, -9),   # Center-left tower
            (-7, -3),
            (7, -3),    # Center-right tower
            (7, -9),
            (11, -9),   # Right battlements
            (11, -12),
            (15, -12),
            (15, -9),
            (13, -9),
            (13, -3),   # Right tower
            (15, -3),   # Wall right
            (15, 15)    # Base right
        ],
        'detail_points': [  # Additional architectural details
            [(-9, 0), (-9, -3)],  # Arrow slits
            [(0, 0), (0, -3)],
            [(9, 0), (9, -3)]
        ]
    }
}

# Decoration settings
DECORATIONS = [
    {
        'type': 'house1',
        'positions': [
            (120, 80),  # Top left
            (SCREEN_WIDTH - 180, 80),  # Top right
            (120, SCREEN_HEIGHT - 180),  # Bottom left
            (SCREEN_WIDTH - 180, SCREEN_HEIGHT - 180),  # Bottom right
        ],
        'image_path': './Assets/The Fan-tasy Tileset (Free) 1.5.1/Art/Buildings/House_Hay_1.png'
    },
    {
        'type': 'tree1',
        'positions': [
            # Top section trees
            (50, 50), (200, 50), (400, 50), (600, 50), (800, 50), (1000, 50),
            # Bottom section trees
            (50, SCREEN_HEIGHT - 100), (200, SCREEN_HEIGHT - 100),
            (400, SCREEN_HEIGHT - 100), (600, SCREEN_HEIGHT - 100),
            (800, SCREEN_HEIGHT - 100), (1000, SCREEN_HEIGHT - 100),
            # Middle safe spots (away from path)
            (150, 300), (900, 300), (150, 500), (900, 500),
        ],
        'image_path': './Assets/The Fan-tasy Tileset (Free) 1.5.1/Art/Trees and Bushes/Tree_Emerald_1.png'
    },    {
        'type': 'tree2',
        'positions': [
            # Trees in safe corners
            (250, 120), (SCREEN_WIDTH - 250, 120),
            (250, SCREEN_HEIGHT - 120), (SCREEN_WIDTH - 250, SCREEN_HEIGHT - 120),
            # Additional safe spots
            (500, 150), (700, 150),
            (500, SCREEN_HEIGHT - 150), (700, SCREEN_HEIGHT - 150)
        ],
        'image_path': './Assets/The Fan-tasy Tileset (Free) 1.5.1/Art/Trees and Bushes/Tree_Emerald_2.png'
    },
    {
        'type': 'rock1',
        'positions': [
            # Rocks near trees for natural grouping
            (80, 80), (180, 80), (SCREEN_WIDTH - 80, 80), (SCREEN_WIDTH - 180, 80),
            (80, SCREEN_HEIGHT - 80), (180, SCREEN_HEIGHT - 80),
            (SCREEN_WIDTH - 80, SCREEN_HEIGHT - 80), (SCREEN_WIDTH - 180, SCREEN_HEIGHT - 80),
            # Additional rocks in safe spots
            (300, 100), (900, 100),
            (300, SCREEN_HEIGHT - 100), (900, SCREEN_HEIGHT - 100)
        ],
        'image_path': './Assets/The Fan-tasy Tileset (Free) 1.5.1/Art/Rocks/Rock_Brown_1.png'
    }
]

# Shop and loadout settings
MAX_LOADOUT_SLOTS = 3
SHOP_GRID_SIZE = (4, 3)  # 4 columns, 3 rows
SHOP_BUTTON_SIZE = (80, 30)
SHOP_PANEL_SIZE = (600, 400)

# Tower definitions
TOWER_SHOP_DATA = {    'basic_archer': {
        'name': 'Basic Archer',
        'cost': 3,  # Affordable starter tower
        'unlock_level': 1,
        'description': 'Standard ranged tower',
        'icon_color': (150, 150, 150)
    },
    'frost_shard': {
        'name': 'Frost Shard',
        'cost': 5,  # Mid-tier utility tower
        'unlock_level': 2,
        'description': 'Slows enemies on hit',
        'icon_color': (100, 200, 255),
        'effect': {
            'name': 'frozen',
            'duration': 2.0
        }
    },    'tesla_coil': {
        'name': 'Tesla Coil',
        'cost': 8,  # Premium multi-target tower
        'unlock_level': 3,
        'description': 'Chain lightning to multiple targets',
        'icon_color': (200, 200, 255),
        'chain_targets': 3,
        'chain_damage_reduction': 0.7
    },
    'bomb_lobber': {
        'name': 'Bomb Lobber',
        'cost': 7,  # Premium AOE tower
        'unlock_level': 4,
        'description': 'Area damage with slow rate',
        'icon_color': (200, 100, 50),
        'splash_radius': 60,
        'splash_damage_falloff': 0.5
    },    'sniper': {
        'name': 'Sniper Nest',
        'cost': 10,  # Premium single-target tower
        'unlock_level': 5,
        'description': 'Long range, high damage',
        'icon_color': (150, 100, 50),
        'instant_kill_threshold': 100  # Instant kill enemies with less than 100 HP
    },
    'gold_golem': {
        'name': 'Gold Golem',
        'cost': 15,  # Most expensive - economy tower
        'unlock_level': 6,
        'description': 'Generates gold over time',
        'icon_color': (255, 215, 0),
        'gold_per_second': 2
    }
}

# Default tower loadout
DEFAULT_LOADOUT = ['basic_archer', 'basic_archer', 'basic_archer']

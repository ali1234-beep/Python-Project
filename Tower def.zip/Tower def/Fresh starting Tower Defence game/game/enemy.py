import time
import pygame
import math
from .constants import ENEMY_TYPES, STATUS_EFFECTS, FPS  # Added FPS import

class Enemy:
    def __init__(self, enemy_type, path, wave_number=1):
        self.type = enemy_type
        self.stats = ENEMY_TYPES[enemy_type].copy()
        self.path = path
        self.current_path_index = 0
        self.distance_traveled = 0
        
        # Get size from stats or use default
        self.radius = self.stats.get('size', 12)
        
        # Scale stats based on wave number
        self.scale_stats(wave_number)
        
        self.position = pygame.Vector2(path[0])
        self.health = self.stats['health']
        self.base_speed = self.stats['speed']  # Store base speed for effects
        self.speed = self.base_speed
        
        # Status effects
        self.active_effects = {}  # {effect_name: {'stacks': int, 'expire_time': float}}
        self.last_effect_time = time.time()
        
        # Visual representation
        self.image = self.create_enemy_image()
        self.rect = self.image.get_rect(center=self.position)
        
    def scale_stats(self, wave_number):
        scaling_factor = 1 + (wave_number - 1) * 0.1
        self.stats['health'] *= scaling_factor
        self.stats['gold_value'] = int(self.stats['gold_value'] * scaling_factor)

    def take_damage(self, damage, damage_type):
        """Handle taking damage with resistance calculations"""
        resistance = self.stats['resistances'].get(damage_type, 1.0)
        actual_damage = damage * resistance
        self.health -= actual_damage
        if self.health <= 0:
            return True  # Enemy died
        return False

    def create_enemy_image(self):
        # Get enemy properties from stats
        size = self.stats.get('size', 12)
        color = self.stats.get('color', (200, 50, 50))
        surface_size = size * 2.5
        
        # Create a surface for the enemy
        surface = pygame.Surface((surface_size, surface_size), pygame.SRCALPHA)
        center = surface_size // 2
        
        if self.type == 'normal':
            # Spiked ball design
            # Main body
            pygame.draw.circle(surface, color, (center, center), size)
            # Spikes
            spike_color = tuple(min(255, c + 30) for c in color)
            for angle in range(0, 360, 45):
                rad = math.radians(angle)
                spike_length = size * 0.4
                end_x = center + math.cos(rad) * (size + spike_length)
                end_y = center + math.sin(rad) * (size + spike_length)
                pygame.draw.line(surface, spike_color, 
                               (center, center), (end_x, end_y), 3)
                               
        elif self.type == 'armored':
            # Armored hexagon design
            # Draw base hexagon
            points = []
            for angle in range(0, 360, 60):
                rad = math.radians(angle)
                x = center + math.cos(rad) * size
                y = center + math.sin(rad) * size
                points.append((x, y))
            pygame.draw.polygon(surface, color, points)
            # Draw inner hexagon for armored look
            inner_points = []
            inner_color = tuple(max(0, c - 30) for c in color)
            for angle in range(0, 360, 60):
                rad = math.radians(angle)
                x = center + math.cos(rad) * (size * 0.7)
                y = center + math.sin(rad) * (size * 0.7)
                inner_points.append((x, y))
            pygame.draw.polygon(surface, inner_color, inner_points)
            
        else:  # fast enemy
            # Arrow-like design
            # Draw triangle pointing in movement direction
            points = [
                (center - size, center + size),  # Bottom left
                (center + size, center),         # Right point
                (center - size, center - size)   # Top left
            ]
            pygame.draw.polygon(surface, color, points)            # Add speed lines
            speed_color = tuple(min(255, c + 50) for c in color)
            for i in range(3):
                offset = (i + 1) * size * 0.4
                pygame.draw.line(surface, speed_color,
                               (center - size - offset, center + size * 0.5),
                               (center - size - offset, center - size * 0.5), 2)
                               
        return surface

    def apply_status(self, effect_name, duration=None, stacks=1):
        """Apply a status effect to the enemy"""
        if effect_name not in STATUS_EFFECTS:
            return False
            
        effect = STATUS_EFFECTS[effect_name]
        current_time = time.time()
        
        # If effect exists and is not stackable, just refresh duration
        if effect_name in self.active_effects and not effect.get('stackable', False):
            self.active_effects[effect_name]['expire_time'] = current_time + (duration or effect['duration'])
            return True
            
        # If effect is new or stackable
        if effect_name not in self.active_effects:
            self.active_effects[effect_name] = {
                'stacks': stacks,
                'expire_time': current_time + (duration or effect['duration'])
            }
        else:
            # Add stacks up to max_stacks
            current_stacks = self.active_effects[effect_name]['stacks']
            max_stacks = effect.get('max_stacks', 1)
            self.active_effects[effect_name]['stacks'] = min(current_stacks + stacks, max_stacks)
            self.active_effects[effect_name]['expire_time'] = current_time + (duration or effect['duration'])
            
        return True
        
    def update_effects(self):
        """Update and process active status effects"""
        current_time = time.time()
        dt = current_time - self.last_effect_time
        self.last_effect_time = current_time
        
        # Reset speed to base value before applying effects
        self.speed = self.base_speed
        
        # Process each active effect
        expired_effects = []
        for effect_name, effect_data in self.active_effects.items():
            if current_time >= effect_data['expire_time']:
                expired_effects.append(effect_name)
                continue
                
            effect = STATUS_EFFECTS[effect_name]
            stacks = effect_data['stacks']
            
            # Apply effect based on type
            if 'damage_per_second' in effect:
                damage = effect['damage_per_second'] * stacks * dt
                self.take_damage(damage, 'effect')
                
            if 'speed_multiplier' in effect:
                self.speed *= effect['speed_multiplier']
                
            if effect_name == 'mana_burn' and 'extra_magic_damage' in effect:
                # Mana burn does instant magic damage when applied
                if not hasattr(effect_data, 'damage_dealt'):
                    self.take_damage(effect['extra_magic_damage'], 'magic')
                    effect_data['damage_dealt'] = True
                    
        # Remove expired effects
        for effect_name in expired_effects:
            del self.active_effects[effect_name]
            
    def move(self, dt=None):
        self.update_effects()  # Update status effects before moving
        
        if self.current_path_index >= len(self.path) - 1:
            return True  # Reached the end
            
        target = pygame.Vector2(self.path[self.current_path_index + 1])
        direction = target - self.position
        distance = direction.length()
        
        # Calculate movement speed based on delta time
        current_speed = self.speed * (dt if dt is not None else 1.0 / FPS)
        
        if distance < current_speed:
            self.position = target
            self.current_path_index += 1
            self.distance_traveled += distance
        else:
            direction.normalize_ip()
            movement = direction * current_speed
            self.position += movement
            self.distance_traveled += movement.length()
            
        self.rect.center = self.position
        return False
        
    def draw(self, screen):
        # Draw the base enemy
        screen.blit(self.image, self.rect)
        
        # Draw health bar
        health_percent = self.health / self.stats['health']
        bar_width = 30
        bar_height = 4
        health_bar_pos = (self.position.x - bar_width/2, self.position.y - 20)
        
        # Health bar background
        pygame.draw.rect(screen, (255, 0, 0), (*health_bar_pos, bar_width, bar_height))
        # Health bar fill
        pygame.draw.rect(screen, (0, 255, 0), 
                        (*health_bar_pos, bar_width * health_percent, bar_height))
                        
        # Draw active status effects
        effect_spacing = 6
        effect_size = 4
        effect_y = self.position.y - 25
        effect_x = self.position.x - (len(self.active_effects) * effect_spacing) / 2
        
        for effect_name in self.active_effects:
            effect_color = STATUS_EFFECTS[effect_name]['color']
            pygame.draw.circle(screen, effect_color, (effect_x, effect_y), effect_size)
            effect_x += effect_spacing

import pygame
from .constants import *
from .debug_log import log_debug

def handle_event(self, event):
    """Handle UI events"""
    if event.type == pygame.MOUSEBUTTONDOWN:
        pos = event.pos
        if not self.game_state.is_game_started:
            if self.buttons['start_game'].collidepoint(pos):
                log_debug("UIMANAGER: Start button clicked, starting game")
                self.game_state.start_game()
                return True
                
        # If the game is started, handle other clicks
        if self.pause_button.collidepoint(pos):
            self.game_state.toggle_pause()
            return True
            
        if self.game_state.is_paused:
            if self.game_state.show_settings:
                self.handle_settings_click(pos)
            else:
                self.handle_pause_menu_click(pos)
            return True
        
        # Game is running, handle normal gameplay clicks
        if self.tower_menu_visible:
            self.handle_tower_menu_click(pos)
        else:
            self.handle_game_click(pos)
        return True
        
    return False

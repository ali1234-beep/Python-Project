import pygame
import sys
import math
from .constants import *
from .medieval_theme import *  # Import medieval theme colors and constants
from .constants import (
    TOWER_SHOP_DATA, MAX_LOADOUT_SLOTS, SHOP_BUTTON_SIZE,
    SHOP_PANEL_SIZE, SHOP_GRID_SIZE, BASE_MAX_HEALTH
)
from .debug_log import log_debug, log_error

class UIManager:
    def __init__(self, game_state):
        self.game_state = game_state
        self.font = pygame.font.Font(None, 24)  # Regular font
        self.large_font = pygame.font.Font(None, 48)  # Larger font for start button
        self.selected_tower = None
        self.tower_menu_visible = False
        self.tower_preview = None  # Store preview tower
        self.pause_button = pygame.Rect(SCREEN_WIDTH - 50, 10, 40, 40)
        # Position shop button in top right, next to pause button
        self.shop_button = pygame.Rect(SCREEN_WIDTH - 100, 10, 40, 40)
        self.setup_ui_elements()
        self.setup_pause_menu()
        self.setup_settings_menu()
        self.slider_dragging = False
        
        # Screen dimensions - will be updated in handle_resize
        self.window_width = 800
        self.window_height = 600
        
        # Shop UI elements
        self.show_shop = False
        self.shop_scroll_offset = 0
        self.shop_panel = None  # Will be set in handle_resize
        self.tower_grid_rects = {}  # Will store tower button rectangles
        self.loadout_rects = []  # Will store loadout slot rectangles
        
        self.handle_resize()

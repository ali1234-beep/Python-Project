import pygame
import sys
import math
from .constants import *
from .medieval_theme import *
from .debug_log import log_debug

class UIManager:
    def __init__(self, game_state):
        self.game_state = game_state
        self.font = pygame.font.Font(None, 24)  # Regular font
        self.large_font = pygame.font.Font(None, 48)  # Larger font for start button
        self.selected_tower = None
        self.tower_menu_visible = False
        self.tower_preview = None  # Store preview tower
        self.pause_button = pygame.Rect(SCREEN_WIDTH - 50, 10, 40, 40)
        self.setup_ui_elements()
        self.setup_pause_menu()
        self.setup_settings_menu()
        self.slider_dragging = False

class CurrencyManager:
    def __init__(self):
        self.gold = 100  # Starting gold
        self.gems = 5    # Starting gems
        
    def add_gold(self, amount):
        """Add gold to the player's balance"""
        self.gold += amount
        
    def spend_gold(self, amount):
        """Spend gold if player has enough"""
        if self.gold >= amount:
            self.gold -= amount
            return True
        return False
        
    def add_gems(self, amount):
        """Add gems to the player's balance"""
        self.gems += amount
        
    def spend_gems(self, amount):
        """Spend gems if player has enough"""
        if self.gems >= amount:
            self.gems -= amount
            return True
        return False
        
    def can_spend(self, amount):
        """Check if player has enough gold to spend"""
        return self.gold >= amount

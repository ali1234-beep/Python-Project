import pygame
from .constants import TOWER_SHOP_DATA, MAX_LOADOUT_SLOTS, DEFAULT_LOADOUT

class ShopManager:
    def __init__(self, game_state):
        self.game_state = game_state
        self.owned_towers = {'basic_archer'}  # Start with basic archer
        self.loadout = list(DEFAULT_LOADOUT)  # Copy default loadout
        self.selected_slot = None
        self.current_level = 1  # Will be updated by game state
        
    def can_afford(self, tower_id):
        """Check if player can afford a tower using gems"""
        if tower_id not in TOWER_SHOP_DATA:
            return False
        return self.game_state.currency_manager.gems >= TOWER_SHOP_DATA[tower_id]['cost']
        
    def is_unlocked(self, tower_id):
        """Check if a tower is unlocked based on level"""
        if tower_id not in TOWER_SHOP_DATA:
            return False
        return self.current_level >= TOWER_SHOP_DATA[tower_id]['unlock_level']
        
    def buy_tower(self, tower_id):
        """Attempt to buy a tower with gems"""
        if not self.can_afford(tower_id) or not self.is_unlocked(tower_id):
            return False
            
        # Deduct gems cost
        cost = TOWER_SHOP_DATA[tower_id]['cost']
        self.game_state.currency_manager.spend_gems(cost)
        
        # Mark as owned
        self.owned_towers.add(tower_id)
        return True
        
    def equip_tower(self, tower_id, slot):
        """Equip a tower to a loadout slot"""
        if not (0 <= slot < MAX_LOADOUT_SLOTS):
            return False
            
        if tower_id not in self.owned_towers:
            return False
            
        # Store old tower and update slot
        old_tower = self.loadout[slot]
        self.loadout[slot] = tower_id
        
        return True
        
    def get_tower_stats(self, tower_id):
        """Get detailed stats for a tower"""
        if tower_id not in TOWER_SHOP_DATA:
            return None
            
        tower = TOWER_SHOP_DATA[tower_id]
        
        stats = {
            'name': tower['name'],
            'cost': tower['cost'],
            'description': tower['description'],
            'owned': tower_id in self.owned_towers,
            'unlocked': self.is_unlocked(tower_id),
            'can_afford': self.can_afford(tower_id)
        }
        
        # Add special attributes if they exist
        for key in ['chain_targets', 'splash_radius', 'gold_per_second', 'instant_kill_threshold']:
            if key in tower:
                stats[key] = tower[key]
                
        return stats
        
    def get_loadout_tower(self, slot):
        """Get the tower ID equipped in a slot"""
        if 0 <= slot < len(self.loadout):
            return self.loadout[slot]
        return None
        
    def set_current_level(self, level):
        """Update the current level - used for unlocking towers"""
        self.current_level = level

# Medieval-themed color palette
PARCHMENT = (242, 235, 220)  # Light aged paper color
DARK_WOOD = (101, 67, 33)    # Rich brown for wooden elements
AGED_STONE = (180, 175, 165) # Weathered stone color
CASTLE_STONE = (140, 135, 125) # Darker stone for buildings
IRON = (130, 120, 110)       # Aged metal color
GOLD_ACCENT = (212, 175, 55) # Rich gold for precious elements
ROYAL_PURPLE = (120, 80, 160) # Deep purple for magical elements
AGED_BRONZE = (175, 150, 100) # Weathered bronze for decorative elements
LEATHER = (150, 110, 80)     # Worn leather color

# UI Gradients
STONE_GRADIENT = [(140, 135, 125), (160, 155, 145)]  # Castle stone gradient
WOOD_GRADIENT = [(101, 67, 33), (121, 87, 53)]       # Dark wood gradient
METAL_GRADIENT = [(130, 120, 110), (150, 140, 130)]  # Aged metal gradient

# Tower-specific colors
ARCHER_COLORS = {
    'base': CASTLE_STONE,
    'accent': DARK_WOOD,
    'highlight': AGED_BRONZE
}

WARRIOR_COLORS = {
    'base': AGED_STONE,
    'accent': IRON,
    'highlight': AGED_BRONZE
}

MAGE_COLORS = {
    'base': (75, 65, 85),      # Dark mystical stone
    'accent': ROYAL_PURPLE,
    'highlight': (200, 180, 220) # Magical sparkle
}

# UI Element colors
PANEL_BACKGROUND = (50, 45, 40)     # Dark aged wood
PANEL_BORDER = AGED_BRONZE
PANEL_HIGHLIGHT = (180, 170, 150)   # Light stone highlight
BUTTON_GRADIENT = [(60, 55, 50), (80, 75, 70)]  # Dark wood button gradient

# Text colors
TEXT_NORMAL = PARCHMENT
TEXT_GOLD = GOLD_ACCENT
TEXT_SHADOW = (30, 25, 20)

import pygame
import math

class Projectile:
    def __init__(self, start_pos, target, damage, damage_type, speed=300):
        self.position = pygame.Vector2(start_pos)
        self.target = target
        self.damage = damage
        self.damage_type = damage_type
        self.speed = speed
        self.size = 4
        
    def update(self):
        """Update projectile position and check for hit. Returns True if projectile should be removed."""
        if not self.target or not hasattr(self.target, 'position'):
            return True
            
        direction = pygame.Vector2(self.target.position) - self.position
        distance = direction.length()
        
        if distance < self.speed / 60:  # Hit target
            self.target.take_damage(self.damage, self.damage_type)
            return True
            
        # Move towards target
        direction.normalize_ip()
        self.position += direction * self.speed / 60
        return False
        
    def draw(self, screen):
        """Draw the projectile"""
        pygame.draw.circle(screen, (255, 255, 255), self.position, self.size)
        
class ChainLightning(Projectile):
    def __init__(self, start_pos, targets, damage, reduction_factor):
        super().__init__(start_pos, targets[0], damage, 'magic', speed=600)
        self.targets = targets
        self.current_target_index = 0
        self.reduction_factor = reduction_factor
        self.chain_positions = [pygame.Vector2(start_pos)]
        
    def update(self):
        """Update chain lightning position and damage"""
        if self.current_target_index >= len(self.targets):
            return True
            
        current_target = self.targets[self.current_target_index]
        if not current_target or not hasattr(current_target, 'position'):
            return True
            
        direction = pygame.Vector2(current_target.position) - self.position
        distance = direction.length()
        
        if distance < self.speed / 60:  # Hit current target
            # Apply damage with reduction for each jump
            reduced_damage = self.damage * (self.reduction_factor ** self.current_target_index)
            current_target.take_damage(reduced_damage, self.damage_type)
            
            # Store position for drawing lightning
            self.chain_positions.append(pygame.Vector2(current_target.position))
            
            # Move to next target
            self.current_target_index += 1
            if self.current_target_index < len(self.targets):
                self.position = pygame.Vector2(current_target.position)
            else:
                return True
                
        # Move towards current target
        direction.normalize_ip()
        self.position += direction * self.speed / 60
        return False
        
    def draw(self, screen):
        """Draw the chain lightning effect"""
        # Draw lightning between all hit positions
        for i in range(len(self.chain_positions) - 1):
            start = self.chain_positions[i]
            end = self.chain_positions[i + 1]
            pygame.draw.line(screen, (100, 200, 255), start, end, 2)
            
        # Draw current projectile position
        if self.current_target_index < len(self.targets):
            pygame.draw.circle(screen, (100, 200, 255), self.position, self.size)
            
class Bomb(Projectile):
    def __init__(self, start_pos, target, damage, radius, falloff):
        super().__init__(start_pos, target, damage, 'magic', speed=200)
        self.radius = radius
        self.falloff = falloff
        self.exploded = False
        self.explosion_frames = 0
        self.max_explosion_frames = 10
        
    def update(self):
        """Update bomb position and handle explosion"""
        if self.exploded:
            self.explosion_frames += 1
            return self.explosion_frames >= self.max_explosion_frames
            
        if not self.target or not hasattr(self.target, 'position'):
            return True
            
        direction = pygame.Vector2(self.target.position) - self.position
        distance = direction.length()
        
        if distance < self.speed / 60:  # Hit target - explode
            self.exploded = True
            # Explosion handled by tower's attack method
            return False
            
        # Move in arc trajectory
        direction.normalize_ip()
        self.position += direction * self.speed / 60
        return False
        
    def draw(self, screen):
        """Draw the bomb and explosion effect"""
        if self.exploded:
            # Draw explosion
            progress = self.explosion_frames / self.max_explosion_frames
            radius = self.radius * (1 - progress)
            color = (255, int(200 * (1 - progress)), 0)
            pygame.draw.circle(screen, color, self.position, radius, 2)
        else:
            # Draw bomb
            pygame.draw.circle(screen, (200, 100, 50), self.position, self.size)

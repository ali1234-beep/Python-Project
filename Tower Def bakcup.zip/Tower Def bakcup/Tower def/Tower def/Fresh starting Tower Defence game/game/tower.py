import pygame
import math
import random
from .constants import *
from .projectile import Projectile, ChainLightning, Bomb

# Tower class with improved projectile handling
class Tower:
    # Target mode constants
    TARGET_FIRST = 'first'
    TARGET_LAST = 'last'
    TARGET_STRONGEST = 'strongest'
    
    # Tower type mapping
    TYPE_MAPPING = {
        'archer': 'basic_archer',
        'warrior': 'warrior',
        'mage': 'mage'
    }
    
    def __init__(self, position, tower_type):
        self.position = pygame.Vector2(position)
        self.type = tower_type
        self.shop_type = self.TYPE_MAPPING.get(tower_type, tower_type)
        self.radius = 15  # Base radius of the tower for selection and collision
        self.level = 1  # Initialize tower at level 1
        self.total_spent = TOWER_TYPES[tower_type]['cost']  # Track total gold spent on tower
        self.target_mode = self.TARGET_FIRST  # Default targeting mode
        self.current_target = None  # Track current target for drawing
        self.rotation = 0  # Current rotation angle in degrees
        self.target_rotation = 0  # Target rotation angle
        self.rotation_speed = 180  # Degrees per second
        
        # Get base stats from tower types data
        tower_data = TOWER_TYPES[tower_type]
        self._stats = {
            'damage': tower_data['damage'],
            'range': tower_data['range'],
            'attack_speed': tower_data['attack_speed']
        }
        
        # Special abilities (will be set by upgrade paths if applicable)
        self.effects = {}  # Status effects the tower can apply
        self.chain_targets = 0  # For Tesla Coil
        self.chain_damage_reduction = 0.7
        self.splash_radius = 0  # For Bomb Lobber
        self.splash_damage_falloff = 0.5
        self.instant_kill_threshold = 0  # For Sniper
        self.gold_per_second = 0  # For Gold Golem
        
        self.target = None
        self.attack_timer = 0
        self.projectiles = []

    @property
    def damage(self):
        return self._stats['damage']
    
    @damage.setter
    def damage(self, value):
        self._stats['damage'] = value
    
    @property
    def range(self):
        return self._stats['range']
    
    @range.setter
    def range(self, value):
        self._stats['range'] = value
    
    @property
    def attack_speed(self):
        return self._stats['attack_speed']
    
    @attack_speed.setter
    def attack_speed(self, value):
        self._stats['attack_speed'] = value

    def get_upgrade_cost(self, attribute):
        """Calculate the cost to upgrade an attribute"""
        base_cost = TOWER_TYPES[self.type]['cost']
        # Upgrades get more expensive with tower level
        level_multiplier = 0.8 + (self.level * 0.2)
        
        if attribute == 'damage':
            return int(base_cost * 0.7 * level_multiplier)
        elif attribute == 'range':
            return int(base_cost * 0.5 * level_multiplier)
        elif attribute == 'attack_speed':
            return int(base_cost * 0.6 * level_multiplier)
        return 0

    def upgrade(self, attribute):
        """Upgrade a specific tower attribute"""
        upgrade_amount = 1.2  # 20% increase per upgrade
        
        if attribute == 'damage':
            self.damage *= upgrade_amount
        elif attribute == 'range':
            self.range *= upgrade_amount
        elif attribute == 'attack_speed':
            self.attack_speed *= upgrade_amount
            
        # Increment level after successful upgrade
        self.level += 1
        # Add upgrade cost to total spent
        self.total_spent += self.get_upgrade_cost(attribute)

    def get_sell_value(self):
        """Calculate the sell value based on total investment"""
        return int(self.total_spent * TOWER_SELL_RATIO)

    def cycle_target_mode(self):
        """Cycle through available targeting modes"""
        if self.target_mode == self.TARGET_FIRST:
            self.target_mode = self.TARGET_LAST
        elif self.target_mode == self.TARGET_LAST:
            self.target_mode = self.TARGET_STRONGEST
        else:
            self.target_mode = self.TARGET_FIRST
        return self.target_mode

    def find_targets(self, enemies):
        """Find all valid targets within range"""
        valid_targets = []
        
        for enemy in enemies:
            distance = pygame.math.Vector2(enemy.position).distance_to(self.position)
            if distance <= self.range:
                valid_targets.append((enemy, distance))
        
        if not valid_targets:
            return []
            
        # Sort based on targeting mode
        if self.target_mode == self.TARGET_FIRST:
            # First in path is already the default sort by distance
            pass
        elif self.target_mode == self.TARGET_LAST:
            valid_targets.sort(key=lambda x: x[1], reverse=True)
        elif self.target_mode == self.TARGET_STRONGEST:
            valid_targets.sort(key=lambda x: x[0].health, reverse=True)
        
        return valid_targets

    def attack(self, current_time, enemies):
        """Perform attack based on tower type"""
        if current_time < self.attack_timer:
            return
            
        # Reset attack timer using property getter
        self.attack_timer = current_time + (1.0 / self.attack_speed)
        
        valid_targets = self.find_targets(enemies)
        if not valid_targets:
            return
            
        self.target = valid_targets[0][0]  # Update current target for drawing
        
        if self.type == 'archer':
            # Create arrow projectile with better accuracy and speed
            projectile = Projectile(
                self.position,
                self.target,
                self.damage,
                'ranged',
                speed=400,  # Fast arrows
                homing=True  # Better accuracy
            )
            self.projectiles.append(projectile)
            
        elif self.type == 'warrior':
            # Melee attack directly applies damage
            self.target.take_damage(self.damage, 'melee')
            
        elif self.type == 'mage':
            # Create magical projectile with special effects based on upgrades
            if 'elementalist' in self.effects:
                # Chain lightning for elementalist upgrade
                nearby_targets = [t[0] for t in valid_targets[:3]]  # Up to 3 targets
                if len(nearby_targets) > 1:
                    projectile = ChainLightning(
                        self.position,
                        nearby_targets,
                        self.damage,
                        reduction_factor=0.7
                    )
                else:
                    projectile = Projectile(
                        self.position,
                        self.target,
                        self.damage,
                        'magic',
                        speed=300,
                        homing=True,
                        mana_burn=True
                    )
            else:
                # Standard magic projectile
                projectile = Projectile(
                    self.position,
                    self.target,
                    self.damage,
                    'magic',
                    speed=300,
                    homing=True
                )
            self.projectiles.append(projectile)

    def update_rotation(self, dt):
        """Update tower rotation to face target"""
        if self.target:
            # Calculate angle to target
            direction = pygame.Vector2(self.target.position) - self.position
            self.target_rotation = math.degrees(math.atan2(-direction.y, direction.x))
            
            # Determine shortest rotation direction
            angle_diff = (self.target_rotation - self.rotation + 180) % 360 - 180
            
            # Rotate towards target at rotation_speed
            if abs(angle_diff) > 1:  # Only rotate if difference is significant
                rotation_amount = self.rotation_speed * dt
                if angle_diff < 0:
                    rotation_amount = -rotation_amount
                self.rotation += min(abs(angle_diff), abs(rotation_amount)) * (1 if angle_diff > 0 else -1)
                self.rotation = self.rotation % 360

    def update(self, dt, enemies):
        """Update tower state and perform attacks"""
        if not enemies:
            return
            
        current_time = pygame.time.get_ticks() / 1000.0
        
        # Update tower rotation
        self.update_rotation(dt)
        
        # Update and remove dead projectiles
        self.projectiles = [p for p in self.projectiles if not p.update(dt)]
        
        # Handle attacks
        self.attack(current_time, enemies)

    def draw(self, screen, is_selected=False):
        """Draw the tower and its projectiles"""
        if self.type == 'archer':
            # Draw tower base
            base_color = TOWER_SHOP_DATA[self.shop_type]['icon_color']
            pygame.draw.rect(screen, base_color, 
                           (self.position.x - 15, self.position.y - 15, 30, 30))
            
            # Draw archer's tower top (crenellations)
            for x in [-10, 0, 10]:
                pygame.draw.rect(screen, (100, 100, 100),
                               (self.position.x + x - 3, self.position.y - 18, 6, 6))
            
            # Draw bow based on current rotation
            bow_radius = 12
            # Convert rotation to radians and adjust for pygame's coordinate system
            angle_rad = math.radians(self.rotation)
            
            # Draw bow string
            string_start = (self.position.x + math.cos(angle_rad - math.pi/6) * bow_radius,
                          self.position.y - math.sin(angle_rad - math.pi/6) * bow_radius)
            string_end = (self.position.x + math.cos(angle_rad + math.pi/6) * bow_radius,
                         self.position.y - math.sin(angle_rad + math.pi/6) * bow_radius)
            pygame.draw.line(screen, (200, 200, 200), string_start, string_end, 1)
            
            # Draw bow arc
            rect = pygame.Rect(self.position.x - bow_radius, self.position.y - bow_radius,
                             bow_radius * 2, bow_radius * 2)
            pygame.draw.arc(screen, (139, 69, 19), rect,
                          angle_rad - math.pi/6, angle_rad + math.pi/6, 3)
            
        elif self.type == 'warrior':
            # Draw warrior tower
            base_color = TOWER_SHOP_DATA[self.shop_type]['icon_color']
            pygame.draw.rect(screen, base_color, 
                           (self.position.x - 15, self.position.y - 15, 30, 30))
            
            # Draw battlements
            for x in [-10, 0, 10]:
                pygame.draw.rect(screen, (120, 120, 120),
                               (self.position.x + x - 4, self.position.y - 18, 8, 8))
            
            # Draw crossed swords based on rotation
            if self.target:
                angle_rad = math.radians(self.rotation)
                for offset in [-math.pi/6, math.pi/6]:
                    # Draw sword blades
                    start_pos = (self.position.x, self.position.y)
                    end_pos = (self.position.x + math.cos(angle_rad + offset) * 15,
                              self.position.y - math.sin(angle_rad + offset) * 15)
                    pygame.draw.line(screen, (192, 192, 192), start_pos, end_pos, 3)
            
        elif self.type == 'mage':
            # Draw mage tower
            base_color = TOWER_SHOP_DATA[self.shop_type]['icon_color']
            pygame.draw.rect(screen, base_color, 
                           (self.position.x - 15, self.position.y - 15, 30, 30))
            
            # Draw spire with rotation
            spire_height = 10
            spire_width = 12
            angle_rad = math.radians(self.rotation)
            
            points = [
                (self.position.x + math.cos(angle_rad) * spire_height,  # Top point
                 self.position.y - math.sin(angle_rad) * spire_height),
                (self.position.x + math.cos(angle_rad + math.pi/2) * spire_width,  # Right base
                 self.position.y - math.sin(angle_rad + math.pi/2) * spire_width),
                (self.position.x + math.cos(angle_rad - math.pi/2) * spire_width,  # Left base
                 self.position.y - math.sin(angle_rad - math.pi/2) * spire_width)
            ]
            pygame.draw.polygon(screen, (100, 50, 150), points)
            
            # Draw magical effects
            if self.target:
                current_time = pygame.time.get_ticks() / 1000.0
                for i in range(3):
                    effect_angle = current_time * 2 + (i * 2 * math.pi / 3) + angle_rad
                    radius = 8
                    effect_pos = (self.position.x + math.cos(effect_angle) * radius,
                                self.position.y - math.sin(effect_angle) * radius)
                    pygame.draw.circle(screen, (150, 100, 255), 
                                    (int(effect_pos[0]), int(effect_pos[1])), 3)
        
        # Draw range indicator if selected
        if is_selected:
            pygame.draw.circle(screen, (255, 255, 255), self.position, 
                             self.range, 1)
            
        # Draw projectiles
        for projectile in self.projectiles:
            projectile.draw(screen)
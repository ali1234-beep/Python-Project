import pygame
import math

class Projectile:
    def __init__(self, start_pos, target, damage, damage_type, speed=300, angle_offset=0, armor_pierce=False, mana_burn=False, homing=False):
        self.position = pygame.Vector2(start_pos)
        self.target = target
        self.damage = damage
        self.damage_type = damage_type
        self.speed = speed
        self.is_active = True
        self.armor_pierce = armor_pierce
        self.mana_burn = mana_burn
        self.homing = homing
        
        # Arrow visual parameters
        self.length = 20
        self.width = 6
        
        # Calculate initial direction
        self.update_direction(angle_offset)
        
    def update_direction(self, angle_offset=0):
        """Update projectile direction to track target"""
        if not self.target or not hasattr(self.target, 'position'):
            return
            
        direction = pygame.Vector2(self.target.position) - self.position
        if direction.length() > 0:
            direction.normalize_ip()
            if angle_offset != 0:
                angle = math.atan2(direction.y, direction.x)
                angle += math.radians(angle_offset)
                direction.x = math.cos(angle)
                direction.y = math.sin(angle)
            self.velocity = direction * self.speed
            self.angle = math.degrees(math.atan2(-direction.y, direction.x))
            
    def update(self, dt):
        """Update projectile position and check for hits"""
        if not self.is_active or not self.target:
            return True
            
        # Update direction if homing
        if self.homing:
            self.update_direction()
        
        # Move towards target
        self.position += self.velocity * dt
        
        # Check if hit target
        if pygame.Vector2(self.position).distance_to(self.target.position) < 10:
            self.target.take_damage(self.damage, self.damage_type)
            return True
            
        return False
        
    def draw(self, screen):
        """Draw the projectile based on its type"""
        if self.damage_type == 'ranged':  # Arrow
            # Create arrow surface
            arrow_surface = pygame.Surface((self.length, self.width), pygame.SRCALPHA)
            
            # Draw arrow shaft (brown)
            pygame.draw.line(arrow_surface, (139, 69, 19), 
                           (0, self.width//2), 
                           (self.length-8, self.width//2), 3)
                           
            # Draw arrowhead (metallic gray)
            arrowhead_points = [
                (self.length-8, 0),  # Left point
                (self.length, self.width//2),  # Tip
                (self.length-8, self.width),  # Right point
            ]
            pygame.draw.polygon(arrow_surface, (192, 192, 192), arrowhead_points)
            
            # Draw fletching (feathers - light gray)
            fletching_points = [
                (2, 0),  # Top point
                (8, self.width//2),  # Middle
                (2, self.width),  # Bottom point
            ]
            pygame.draw.polygon(arrow_surface, (220, 220, 220), fletching_points)
            
            # Rotate arrow
            rotated_arrow = pygame.transform.rotate(arrow_surface, self.angle)
            
            # Draw centered on position
            screen.blit(rotated_arrow, 
                       (self.position.x - rotated_arrow.get_width()//2,
                        self.position.y - rotated_arrow.get_height()//2))
            
        elif self.damage_type == 'magic':  # Magic projectile
            # Draw magical orb with glow
            pygame.draw.circle(screen, (180, 100, 255, 128), 
                             (int(self.position.x), int(self.position.y)), 6)
            pygame.draw.circle(screen, (255, 255, 255), 
                             (int(self.position.x), int(self.position.y)), 4)
        
class ChainLightning(Projectile):
    def __init__(self, start_pos, targets, damage, reduction_factor):
        super().__init__(start_pos, targets[0], damage, 'magic', speed=600)
        self.targets = targets
        self.current_target_index = 0
        self.reduction_factor = reduction_factor
        self.chain_positions = [pygame.Vector2(start_pos)]
        
    def update(self):
        """Update chain lightning position and damage"""
        if self.current_target_index >= len(self.targets):
            return True
            
        current_target = self.targets[self.current_target_index]
        if not current_target or not hasattr(current_target, 'position'):
            return True
            
        direction = pygame.Vector2(current_target.position) - self.position
        distance = direction.length()
        
        if distance < self.speed / 60:  # Hit current target
            # Apply damage with reduction for each jump
            reduced_damage = self.damage * (self.reduction_factor ** self.current_target_index)
            current_target.take_damage(reduced_damage, self.damage_type)
            
            # Store position for drawing lightning
            self.chain_positions.append(pygame.Vector2(current_target.position))
            
            # Move to next target
            self.current_target_index += 1
            if self.current_target_index < len(self.targets):
                self.position = pygame.Vector2(current_target.position)
            else:
                return True
                
        # Move towards current target
        direction.normalize_ip()
        self.position += direction * self.speed / 60
        return False
        
    def draw(self, screen):
        """Draw the chain lightning effect"""
        # Draw lightning between all hit positions
        for i in range(len(self.chain_positions) - 1):
            start = self.chain_positions[i]
            end = self.chain_positions[i + 1]
            pygame.draw.line(screen, (100, 200, 255), start, end, 2)
            
        # Draw current projectile position
        if self.current_target_index < len(self.targets):
            pygame.draw.circle(screen, (100, 200, 255), self.position, self.size)
            
class Bomb(Projectile):
    def __init__(self, start_pos, target, damage, radius, falloff):
        super().__init__(start_pos, target, damage, 'magic', speed=200)
        self.radius = radius
        self.falloff = falloff
        self.exploded = False
        self.explosion_frames = 0
        self.max_explosion_frames = 10
        
    def update(self):
        """Update bomb position and handle explosion"""
        if self.exploded:
            self.explosion_frames += 1
            return self.explosion_frames >= self.max_explosion_frames
            
        if not self.target or not hasattr(self.target, 'position'):
            return True
            
        direction = pygame.Vector2(self.target.position) - self.position
        distance = direction.length()
        
        if distance < self.speed / 60:  # Hit target - explode
            self.exploded = True
            # Explosion handled by tower's attack method
            return False
            
        # Move in arc trajectory
        direction.normalize_ip()
        self.position += direction * self.speed / 60
        return False
        
    def draw(self, screen):
        """Draw the bomb and explosion effect"""
        if self.exploded:
            # Draw explosion
            progress = self.explosion_frames / self.max_explosion_frames
            radius = self.radius * (1 - progress)
            color = (255, int(200 * (1 - progress)), 0)
            pygame.draw.circle(screen, color, self.position, radius, 2)
        else:
            # Draw bomb
            pygame.draw.circle(screen, (200, 100, 50), self.position, self.size)

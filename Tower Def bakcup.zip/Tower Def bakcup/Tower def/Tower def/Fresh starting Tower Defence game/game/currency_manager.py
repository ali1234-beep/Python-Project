from .constants import *

class CurrencyManager:
    def __init__(self):
        self.gold = STARTING_GOLD  # Starting gold value from constants
        self.gems = 0    # Starting gems
        
    def add_gold(self, amount):
        """Add gold to the player's balance"""
        self.gold += amount
        
    def spend_gold(self, amount):
        """Spend gold if player has enough"""
        if self.gold >= amount:
            self.gold -= amount
            return True
        return False
        
    def add_gems(self, amount):
        """Add gems to the player's balance"""
        self.gems += amount
        
    def spend_gems(self, amount):
        """Spend gems if player has enough"""
        if self.gems >= amount:
            self.gems -= amount
            return True
        return False
        
    def spend(self, amount):
        """Spend gold if player has enough"""
        return self.spend_gold(amount)
        
    def can_spend(self, amount):
        """Check if player has enough gold to spend"""
        return self.gold >= amount

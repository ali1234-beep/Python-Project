import pygame
from .constants import *
from .tower import Tower
from .debug_log import log_debug

class TowerManager:
    def __init__(self, currency_manager):
        self.towers = []
        self.selected_tower = None
        self.currency_manager = currency_manager
        self.game_state = None  # Will be set by GameState

    def is_near_path(self, position, game_state):
        """Check if a position is too close to the path"""
        if not game_state or not game_state.wave_manager or not game_state.wave_manager.path:
            return False
            
        path_points = game_state.wave_manager.path
        mouse_pos = pygame.math.Vector2(position)
        
        # Check distance to each path segment
        for i in range(len(path_points) - 1):
            start = pygame.math.Vector2(path_points[i])
            end = pygame.math.Vector2(path_points[i + 1])
            
            # Get vector for path segment
            segment = end - start
            if segment.length_squared() == 0:
                continue
                
            # Get vector from start to mouse
            to_mouse = mouse_pos - start
            
            # Project mouse position onto path segment
            t = max(0, min(1, to_mouse.dot(segment) / segment.length_squared()))
            
            # Find closest point on path segment
            closest = start + segment * t
            
            # Check distance to closest point
            distance = (mouse_pos - closest).length()
            
            # PATH_WIDTH/2 + extra margin for tower radius
            if distance < (PATH_WIDTH/2 + 30):
                return True
                
        return False

    def can_place_tower(self, position):
        """Check if a tower can be placed at the given position"""
        # Convert position to tuple for consistency
        position = (int(position[0]), int(position[1]))
        
        # Check if we've reached the tower limit
        if len(self.towers) >= MAX_TOWERS:
            return False
            
        # Check if position is valid (not overlapping other towers)
        for tower in self.towers:
            if pygame.math.Vector2(position).distance_to(tower.position) < 40:
                return False
                
        # Check if tower is too close to path - do this check last
        if self.is_near_path(position, self.game_state):
            return False
                
        return True

    def try_place_tower(self, position, tower_type):
        """Attempt to place a tower at the given position"""
        # Convert position to tuple for consistency
        position = (int(position[0]), int(position[1]))
        
        # Check if we've reached the tower limit
        if len(self.towers) >= MAX_TOWERS:
            return False
            
        # Check if we can afford the tower
        tower_data = TOWER_TYPES[tower_type]
        cost = tower_data['cost']
        if not self.currency_manager.can_spend(cost):
            return False
            
        # Check if position is valid (not overlapping other towers)
        if self.is_position_occupied(position):
            return False
                
        # Check if tower is too close to path - do this check last
        if self.is_near_path(position, self.game_state):
            return False
                
        # All checks passed, spend gold and place the tower
        self.currency_manager.spend_gold(cost)
        new_tower = Tower(position, tower_type)
        self.towers.append(new_tower)
        return True

    def select_tower(self, position):
        """Select a tower at the given position"""
        # Convert position to Vector2 for easier distance calculation
        pos_vec = pygame.math.Vector2(position)
        
        # Check towers in reverse order (top-most first)
        for tower in reversed(self.towers):
            if pos_vec.distance_to(tower.position) < 20:  # Fixed selection radius
                self.selected_tower = tower
                return tower
                
        self.selected_tower = None
        return None

    def sell_tower(self, tower):
        """Sell the given tower"""
        if tower in self.towers:
            self.currency_manager.add_gold(tower.get_sell_value())
            self.towers.remove(tower)
            if tower == self.selected_tower:
                self.selected_tower = None

    def upgrade_tower(self, tower, attribute):
        """Upgrade a specific attribute of the given tower"""
        if tower in self.towers:
            cost = tower.get_upgrade_cost(attribute)
            if self.currency_manager.can_spend(cost):
                self.currency_manager.spend(cost)
                tower.upgrade(attribute)
                return True
            return False
        return False

    def update(self, dt):
        """Update all towers"""
        # Get the current list of enemies from the enemy manager
        enemies = self.game_state.enemy_manager.enemies if self.game_state else []
        
        for tower in self.towers:
            tower.update(dt, enemies)
            
            # Handle gold generation for gold golems
            if hasattr(tower, 'gold_per_second'):
                self.currency_manager.add_gold(tower.gold_per_second / FPS)
            
    def draw(self, screen):
        """Draw all towers and selection indicators"""
        for tower in self.towers:
            # Draw tower with selection state
            tower.draw(screen, tower == self.selected_tower)
            # Draw selection ring if tower is selected
            if tower == self.selected_tower:
                pygame.draw.circle(screen, (255, 255, 0), tower.position, tower.radius + 3, 2)

    def is_position_occupied(self, position, radius=40):
        """Check if a position is already occupied by another tower"""
        if isinstance(position, pygame.Vector2):
            position = (position.x, position.y)

        position_vec = pygame.math.Vector2(position)
        for tower in self.towers:
            tower_pos = tower.position if isinstance(tower.position, tuple) else (tower.position.x, tower.position.y)
            distance = position_vec.distance_to(pygame.math.Vector2(tower_pos))
            if distance < radius:
                return True
        return False

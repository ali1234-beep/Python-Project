import pygame
import sys
from game.game_state import GameState
from game.constants import *
from game.debug_log import setup_debug_logging, log_debug

class Game:
    def __init__(self):
        setup_debug_logging()
        pygame.init()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("Medieval Tower Defense")
        self.clock = pygame.time.Clock()
        self.game_state = GameState()

    def run(self):
        while True:
            # Calculate delta time in seconds
            dt = self.clock.tick(FPS) / 1000.0  # Convert milliseconds to seconds
            
            # Event handling
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    log_debug(f"MAIN: Received mouse click at {event.pos}")
                self.game_state.handle_event(event)

            # Update game state
            self.game_state.update(dt)

            # Draw everything
            self.screen.fill(BACKGROUND_COLOR)
            self.game_state.draw(self.screen)
            pygame.display.flip()

if __name__ == "__main__":
    game = Game()
    game.run()
